/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

interface Particle {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  life: number;
  maxLife: number;
  scaleDecay: number;
  colorFade?: boolean;
}

interface BulletTracer {
  line: THREE.Line;
  life: number;
  maxLife: number;
}

export class ParticleSystem {
  private scene: THREE.Scene;
  private particles: Particle[] = [];
  private tracers: BulletTracer[] = [];
  private poolGeoSphere: THREE.SphereGeometry;
  private poolGeoSpark: THREE.BoxGeometry;
  private matFire: THREE.MeshBasicMaterial;
  private matSmoke: THREE.MeshBasicMaterial;
  private matSpark: THREE.MeshBasicMaterial;
  private matBlood: THREE.MeshBasicMaterial;
  private tracerMaterial: THREE.LineBasicMaterial;
  private flashLight: THREE.PointLight;
  private flashTimer = 0;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.poolGeoSphere = new THREE.SphereGeometry(0.12, 6, 6);
    this.poolGeoSpark = new THREE.BoxGeometry(0.06, 0.06, 0.06);

    this.matFire = new THREE.MeshBasicMaterial({ color: 0xff6600 });
    this.matSmoke = new THREE.MeshBasicMaterial({ color: 0x444444, transparent: true, opacity: 0.8 });
    this.matSpark = new THREE.MeshBasicMaterial({ color: 0xffea00 });
    this.matBlood = new THREE.MeshBasicMaterial({ color: 0x880000 });
    this.tracerMaterial = new THREE.LineBasicMaterial({ color: 0xffdd44, linewidth: 2 });

    // Dynamic muzzle/explosion point light
    this.flashLight = new THREE.PointLight(0xff9900, 0, 15);
    this.scene.add(this.flashLight);
  }

  public triggerMuzzleFlash(position: THREE.Vector3, direction: THREE.Vector3) {
    this.flashLight.position.copy(position);
    this.flashLight.intensity = 5;
    this.flashLight.color.setHex(0xffaa22);
    this.flashTimer = 0.06;

    // Small flash particles
    for (let i = 0; i < 4; i++) {
      const mesh = new THREE.Mesh(this.poolGeoSpark, this.matSpark);
      mesh.position.copy(position);
      const vel = direction.clone().multiplyScalar(4 + Math.random() * 4);
      vel.x += (Math.random() - 0.5) * 1.5;
      vel.y += (Math.random() - 0.5) * 1.5;
      vel.z += (Math.random() - 0.5) * 1.5;

      this.scene.add(mesh);
      this.particles.push({
        mesh,
        velocity: vel,
        life: 0,
        maxLife: 0.12,
        scaleDecay: 0.9,
      });
    }
  }

  public createTracer(start: THREE.Vector3, end: THREE.Vector3) {
    const points = [start.clone(), end.clone()];
    const geo = new THREE.BufferGeometry().setFromPoints(points);
    const line = new THREE.Line(geo, this.tracerMaterial);
    this.scene.add(line);
    this.tracers.push({
      line,
      life: 0,
      maxLife: 0.08,
    });
  }

  public triggerImpact(position: THREE.Vector3, isFlesh = false) {
    const count = isFlesh ? 6 : 8;
    const mat = isFlesh ? this.matBlood : this.matSpark;

    for (let i = 0; i < count; i++) {
      const mesh = new THREE.Mesh(this.poolGeoSpark, mat);
      mesh.position.copy(position);
      const vel = new THREE.Vector3(
        (Math.random() - 0.5) * 3,
        Math.random() * 2.5 + 0.5,
        (Math.random() - 0.5) * 3
      );
      this.scene.add(mesh);
      this.particles.push({
        mesh,
        velocity: vel,
        life: 0,
        maxLife: 0.25 + Math.random() * 0.15,
        scaleDecay: 0.85,
      });
    }
  }

  public triggerExplosion(position: THREE.Vector3, scale = 1.0) {
    this.flashLight.position.copy(position);
    this.flashLight.intensity = 15 * scale;
    this.flashLight.color.setHex(0xff5500);
    this.flashTimer = 0.25;

    // Fiery blast fragments
    for (let i = 0; i < 24; i++) {
      const mesh = new THREE.Mesh(this.poolGeoSphere, this.matFire);
      mesh.position.copy(position);
      mesh.scale.setScalar(scale * (0.8 + Math.random() * 1.2));

      const angle = Math.random() * Math.PI * 2;
      const speed = (4 + Math.random() * 9) * scale;
      const vel = new THREE.Vector3(
        Math.cos(angle) * speed,
        Math.random() * 8 * scale + 2,
        Math.sin(angle) * speed
      );

      this.scene.add(mesh);
      this.particles.push({
        mesh,
        velocity: vel,
        life: 0,
        maxLife: 0.45 + Math.random() * 0.3,
        scaleDecay: 0.94,
      });
    }

    // Expanding dark smoke cloud
    for (let i = 0; i < 16; i++) {
      const mesh = new THREE.Mesh(this.poolGeoSphere, this.matSmoke);
      mesh.position.copy(position);
      mesh.position.y += Math.random() * 0.8;
      mesh.scale.setScalar(scale * (1.2 + Math.random() * 1.5));

      const vel = new THREE.Vector3(
        (Math.random() - 0.5) * 3 * scale,
        Math.random() * 3 * scale + 1.2,
        (Math.random() - 0.5) * 3 * scale
      );

      this.scene.add(mesh);
      this.particles.push({
        mesh,
        velocity: vel,
        life: 0,
        maxLife: 1.0 + Math.random() * 0.6,
        scaleDecay: 1.02, // gently expands then vanishes
      });
    }
  }

  public update(delta: number) {
    // Flash light decay
    if (this.flashTimer > 0) {
      this.flashTimer -= delta;
      if (this.flashTimer <= 0) {
        this.flashLight.intensity = 0;
      }
    }

    // Update tracers
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const t = this.tracers[i];
      t.life += delta;
      if (t.life >= t.maxLife) {
        this.scene.remove(t.line);
        t.line.geometry.dispose();
        this.tracers.splice(i, 1);
      }
    }

    // Update particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += delta;

      p.mesh.position.addScaledVector(p.velocity, delta);
      p.velocity.y -= 9.8 * delta; // gravity
      p.mesh.scale.multiplyScalar(p.scaleDecay);

      if (p.life >= p.maxLife || p.mesh.scale.x < 0.02) {
        this.scene.remove(p.mesh);
        this.particles.splice(i, 1);
      }
    }
  }

  public cleanup() {
    this.particles.forEach((p) => {
      this.scene.remove(p.mesh);
    });
    this.particles = [];
    this.tracers.forEach((t) => {
      this.scene.remove(t.line);
      t.line.geometry.dispose();
    });
    this.tracers = [];
    this.scene.remove(this.flashLight);
  }
}
