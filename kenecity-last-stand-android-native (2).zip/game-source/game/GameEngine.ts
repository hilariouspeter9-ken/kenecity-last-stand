/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  GameSettings,
  MissionConfig,
  PlayerInventory,
  PlayerStats,
  WeaponType,
} from '../types/game';
import { soundManager } from '../audio/SoundManager';
import { WEAPON_CONFIGS } from './weapons';
import {
  createBuilding,
  createExplosiveBarrel,
  createHumvee,
  createRadarDish,
  createSandbagBarrier,
  createSoldier,
  createSupplyCrate,
  createTree,
  createWatchtower,
  createWeaponMesh,
  materials,
  SoldierRig,
} from './proceduralModels';
import { ParticleSystem } from './ParticleSystem';

export interface EnemyEntity {
  id: string;
  rig: SoldierRig;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  rotation: number;
  hp: number;
  maxHp: number;
  type: 'rifleman' | 'shotgunner' | 'sniper' | 'heavy' | 'boss';
  weapon: WeaponType;
  weaponMesh: THREE.Group;
  state: 'patrol' | 'alert' | 'chase' | 'attack' | 'cover' | 'dead';
  patrolTarget: THREE.Vector3;
  attackCooldown: number;
  burstCount: number;
  isDead: boolean;
  deathTimer: number;
  alertTimer: number;
  isBoss?: boolean;
}

export interface GrenadeEntity {
  mesh: THREE.Group;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  fuseTimer: number;
}

export interface WorldProp {
  type: 'barrel' | 'crate' | 'radar' | 'barrier' | 'building' | 'humvee';
  mesh: THREE.Group;
  box: THREE.Box3;
  hp?: number;
  isDestroyed?: boolean;
}

export class GameEngine {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  private canvasContainer: HTMLElement;

  // Systems
  private particles: ParticleSystem;

  // Game state
  public mission: MissionConfig;
  public settings: GameSettings;
  public playerStats: PlayerStats;
  public inventory: PlayerInventory;
  public isPaused = false;
  public isGameOver = false;
  public isVictory = false;

  // Player 3D
  public playerRig: SoldierRig;
  public playerPosition = new THREE.Vector3(0, 0, 0);
  private playerVelocity = new THREE.Vector3(0, 0, 0);
  private playerRotation = 0; // yaw
  private cameraPitch = 0.15; // pitch
  private cameraDistance = 3.6;
  private cameraTarget = new THREE.Vector3();
  private isGrounded = true;
  private walkCycle = 0;
  private currentWeaponMesh: THREE.Group | null = null;
  private reloadTimer = 0;
  private fireTimer = 0;
  private isFiring = false;

  // Controls input
  private inputMove = new THREE.Vector2(0, 0); // x: strafe, y: forward/back
  private lookDelta = new THREE.Vector2(0, 0);

  // Entities
  public enemies: EnemyEntity[] = [];
  public grenades: GrenadeEntity[] = [];
  public worldProps: WorldProp[] = [];

  // Mission 4 waves
  private currentWave = 1;
  private waveEnemiesSpawned = 0;

  // Loop & timing
  private clock = new THREE.Clock();
  private animFrameId = 0;
  private isDestroyed = false;

  // Callbacks
  public onStatsChanged?: (stats: PlayerStats, inv: PlayerInventory) => void;
  public onMissionObjectiveUpdated?: (mission: MissionConfig) => void;
  public onMissionCompleted?: (victory: boolean, stats: PlayerStats) => void;
  public onHitFeedback?: (isHeadshot: boolean) => void;

  constructor(container: HTMLElement, mission: MissionConfig, settings: GameSettings, inventory: PlayerInventory) {
    this.canvasContainer = container;
    this.mission = JSON.parse(JSON.stringify(mission)); // deep copy objectives
    this.settings = settings;
    this.inventory = JSON.parse(JSON.stringify(inventory));

    this.playerStats = {
      hp: 100,
      maxHp: 100,
      armor: 100,
      maxArmor: 100,
      score: 0,
      kills: 0,
      headshots: 0,
      shotsFired: 0,
      shotsHit: 0,
      isDead: false,
      isCrouched: false,
      isAiming: false,
      isSprinting: false,
      isReloading: false,
    };

    // 1. Scene
    this.scene = new THREE.Scene();

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(65, container.clientWidth / container.clientHeight, 0.1, 400);

    // 3. Renderer with graphics preset config
    const isLow = settings.graphicsQuality === 'LOW';
    const isHigh = settings.graphicsQuality === 'HIGH';

    this.renderer = new THREE.WebGLRenderer({
      powerPreference: 'high-performance',
      antialias: !isLow,
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(isLow ? 1.0 : Math.min(window.devicePixelRatio, isHigh ? 2.0 : 1.3));
    this.renderer.shadowMap.enabled = !isLow;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 4. Studio Environment
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // 5. Particles
    this.particles = new ParticleSystem(this.scene);

    // 6. Player Rig
    this.playerRig = createSoldier(false);
    this.scene.add(this.playerRig.root);
    this.attachWeaponToPlayer(this.inventory.weapons[this.inventory.currentWeaponIndex]);

    // 7. Setup Environment & Lighting for Mission
    this.setupMissionEnvironment();

    // 8. Spawn Enemies for Mission
    this.spawnMissionEnemies();

    // 9. Start Game Loop & Music
    soundManager.startMusic(this.mission.musicMood);
    this.startLoop();
  }

  // --- ENVIRONMENT SETUP ---
  private setupMissionEnvironment() {
    const { timeOfDay } = this.mission;

    let skyColor = 0x6e94b8;
    let horizonColor = 0xb4c7d9;
    let lightColor = 0xfff0dd;
    let lightIntensity = 2.4;

    if (timeOfDay === 'sunset') {
      skyColor = 0xd86a34;
      horizonColor = 0x8a3832;
      lightColor = 0xff8844;
      lightIntensity = 2.0;
    } else if (timeOfDay === 'night') {
      skyColor = 0x0a101d;
      horizonColor = 0x141b2b;
      lightColor = 0x48648c;
      lightIntensity = 0.9;
    }

    this.scene.background = new THREE.Color(skyColor);
    this.scene.fog = new THREE.FogExp2(horizonColor, 0.012);

    // Key Light
    const dirLight = new THREE.DirectionalLight(lightColor, lightIntensity);
    dirLight.position.set(40, 60, 30);
    dirLight.castShadow = this.settings.graphicsQuality !== 'LOW';
    dirLight.shadow.mapSize.width = this.settings.graphicsQuality === 'HIGH' ? 2048 : 1024;
    dirLight.shadow.mapSize.height = this.settings.graphicsQuality === 'HIGH' ? 2048 : 1024;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 160;
    const d = 50;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0004;
    this.scene.add(dirLight);

    // Fill Light
    const hemiLight = new THREE.HemisphereLight(skyColor, 0x222622, 1.2);
    this.scene.add(hemiLight);

    // Ground: Vast military terrain
    const groundGeo = new THREE.PlaneGeometry(300, 300);
    const groundMesh = new THREE.Mesh(groundGeo, materials.dirt);
    groundMesh.rotation.x = -Math.PI / 2;
    groundMesh.receiveShadow = true;
    this.scene.add(groundMesh);

    // Asphalt Main Street
    const roadGeo = new THREE.PlaneGeometry(24, 240);
    const roadMesh = new THREE.Mesh(roadGeo, materials.asphalt);
    roadMesh.rotation.x = -Math.PI / 2;
    roadMesh.position.set(0, 0.02, 0);
    roadMesh.receiveShadow = true;
    this.scene.add(roadMesh);

    // Cross Street
    const crossRoadGeo = new THREE.PlaneGeometry(160, 20);
    const crossRoad = new THREE.Mesh(crossRoadGeo, materials.asphalt);
    crossRoad.rotation.x = -Math.PI / 2;
    crossRoad.position.set(0, 0.022, 0);
    crossRoad.receiveShadow = true;
    this.scene.add(crossRoad);

    // Add Architectural Buildings along the streets
    const buildingsData = [
      { x: -25, z: -35, w: 20, h: 14, d: 24 },
      { x: 26, z: -35, w: 22, h: 18, d: 26 },
      { x: -28, z: 40, w: 24, h: 12, d: 22 },
      { x: 28, z: 45, w: 20, h: 16, d: 24 },
      { x: -32, z: -85, w: 26, h: 22, d: 26 },
      { x: 30, z: -85, w: 24, h: 20, d: 28 },
    ];

    buildingsData.forEach(({ x, z, w, h, d }) => {
      const b = createBuilding(w, h, d);
      b.position.set(x, 0, z);
      this.scene.add(b);
      this.worldProps.push({
        type: 'building',
        mesh: b,
        box: new THREE.Box3().setFromObject(b),
      });
    });

    // Watchtowers at tactical perimeters
    const tower1 = createWatchtower();
    tower1.position.set(-18, 0, -60);
    this.scene.add(tower1);
    this.worldProps.push({ type: 'building', mesh: tower1, box: new THREE.Box3().setFromObject(tower1) });

    const tower2 = createWatchtower();
    tower2.position.set(18, 0, 70);
    this.scene.add(tower2);
    this.worldProps.push({ type: 'building', mesh: tower2, box: new THREE.Box3().setFromObject(tower2) });

    // Abandoned Humvees & Barricades for tactical cover
    const humveePositions = [
      { x: -4, z: -15, rot: 0.3 },
      { x: 6, z: 25, rot: -0.4 },
      { x: -5, z: 80, rot: 1.1 },
      { x: 7, z: -70, rot: -0.8 },
    ];
    humveePositions.forEach(({ x, z, rot }) => {
      const h = createHumvee();
      h.position.set(x, 0, z);
      h.rotation.y = rot;
      this.scene.add(h);
      this.worldProps.push({ type: 'humvee', mesh: h, box: new THREE.Box3().setFromObject(h) });
    });

    // Sandbag Fortifications
    const sandbagPositions = [
      { x: -3, z: -8, rot: 0 },
      { x: 3, z: 12, rot: Math.PI / 4 },
      { x: -6, z: 35, rot: -Math.PI / 3 },
      { x: 0, z: -45, rot: 0 },
    ];
    sandbagPositions.forEach(({ x, z, rot }) => {
      const s = createSandbagBarrier();
      s.position.set(x, 0, z);
      s.rotation.y = rot;
      this.scene.add(s);
      this.worldProps.push({ type: 'barrier', mesh: s, box: new THREE.Box3().setFromObject(s) });
    });

    // Explosive Red Barrels (can be detonated by player shooting!)
    const barrelPositions = [
      { x: 8, z: -12 },
      { x: 9, z: -13 },
      { x: -7, z: 20 },
      { x: 4, z: 50 },
      { x: -8, z: -55 },
      { x: -9, z: -54 },
      { x: 5, z: -78 },
    ];
    barrelPositions.forEach(({ x, z }) => {
      const b = createExplosiveBarrel();
      b.position.set(x, 0, z);
      this.scene.add(b);
      this.worldProps.push({
        type: 'barrel',
        mesh: b,
        box: new THREE.Box3().setFromObject(b),
        hp: 20,
        isDestroyed: false,
      });
    });

    // Ammo / Health Supply Crates
    const cratePositions = [
      { x: -3, z: -6, med: true },
      { x: 5, z: 20, med: false },
      { x: -6, z: 45, med: true },
      { x: 7, z: -48, med: false },
    ];
    cratePositions.forEach(({ x, z, med }) => {
      const c = createSupplyCrate(med);
      c.position.set(x, 0, z);
      this.scene.add(c);
      this.worldProps.push({
        type: 'crate',
        mesh: c,
        box: new THREE.Box3().setFromObject(c),
        isDestroyed: false,
      });
    });

    // Mission 3 Comms Radar Relays
    if (this.mission.id === 3) {
      const radarPos = [
        { x: -16, z: -40 },
        { x: 16, z: -45 },
        { x: 0, z: -90 },
      ];
      radarPos.forEach(({ x, z }) => {
        const dish = createRadarDish();
        dish.position.set(x, 0, z);
        this.scene.add(dish);
        this.worldProps.push({
          type: 'radar',
          mesh: dish,
          box: new THREE.Box3().setFromObject(dish),
          hp: 120,
          isDestroyed: false,
        });
      });
    }

    // Trees on perimeters
    for (let i = 0; i < 28; i++) {
      const tree = createTree();
      const side = i % 2 === 0 ? 1 : -1;
      tree.position.set(side * (30 + Math.random() * 40), 0, (Math.random() - 0.5) * 220);
      tree.rotation.y = Math.random() * Math.PI * 2;
      this.scene.add(tree);
    }
  }

  // --- ENEMY SPAWNING ---
  private spawnMissionEnemies() {
    this.enemies = [];
    const count = this.mission.enemyCount;

    for (let i = 0; i < count; i++) {
      const isBoss = this.mission.hasBoss && i === count - 1;
      let enemyType: EnemyEntity['type'] = 'rifleman';
      let weapon: WeaponType = 'rifle';
      let hp = 70;

      if (isBoss) {
        enemyType = 'boss';
        weapon = 'rifle';
        hp = 650;
      } else if (i % 4 === 1) {
        enemyType = 'shotgunner';
        weapon = 'shotgun';
        hp = 95;
      } else if (i % 4 === 2) {
        enemyType = 'sniper';
        weapon = 'sniper';
        hp = 55;
      } else if (i % 4 === 3) {
        enemyType = 'heavy';
        weapon = 'smg';
        hp = 140;
      }

      const rig = createSoldier(true, isBoss);
      const weaponMesh = createWeaponMesh(weapon);
      rig.weaponMount.add(weaponMesh);

      // Distance down the sector
      const zOffset = isBoss ? -95 : -15 - (i * 7);
      const xOffset = (Math.random() - 0.5) * 18;
      rig.root.position.set(xOffset, 0, zOffset);
      this.scene.add(rig.root);

      this.enemies.push({
        id: `enemy_${i}`,
        rig,
        position: rig.root.position,
        velocity: new THREE.Vector3(),
        rotation: 0,
        hp,
        maxHp: hp,
        type: enemyType,
        weapon,
        weaponMesh,
        state: 'patrol',
        patrolTarget: new THREE.Vector3(xOffset + (Math.random() - 0.5) * 6, 0, zOffset + (Math.random() - 0.5) * 6),
        attackCooldown: 1.0 + Math.random() * 1.5,
        burstCount: 0,
        isDead: false,
        deathTimer: 0,
        alertTimer: 0,
        isBoss,
      });
    }
  }

  // --- WEAPON SYSTEM ---
  public attachWeaponToPlayer(weaponType: WeaponType) {
    if (this.currentWeaponMesh) {
      this.playerRig.weaponMount.remove(this.currentWeaponMesh);
    }
    this.currentWeaponMesh = createWeaponMesh(weaponType);
    this.playerRig.weaponMount.add(this.currentWeaponMesh);
  }

  public switchWeapon(index: number) {
    if (index < 0 || index >= this.inventory.weapons.length || index === this.inventory.currentWeaponIndex) return;
    this.inventory.currentWeaponIndex = index;
    const newWeapon = this.inventory.weapons[index];
    this.attachWeaponToPlayer(newWeapon);
    soundManager.playButtonClick();
    this.notifyStats();
  }

  public nextWeapon() {
    const nextIdx = (this.inventory.currentWeaponIndex + 1) % this.inventory.weapons.length;
    this.switchWeapon(nextIdx);
  }

  public prevWeapon() {
    const prevIdx = (this.inventory.currentWeaponIndex - 1 + this.inventory.weapons.length) % this.inventory.weapons.length;
    this.switchWeapon(prevIdx);
  }

  public startFiring() {
    this.isFiring = true;
  }

  public stopFiring() {
    this.isFiring = false;
  }

  public setAiming(aiming: boolean) {
    this.playerStats.isAiming = aiming;
    this.notifyStats();
  }

  public toggleAim() {
    this.setAiming(!this.playerStats.isAiming);
  }

  public setCrouched(crouched: boolean) {
    this.playerStats.isCrouched = crouched;
    this.notifyStats();
  }

  public toggleCrouch() {
    this.setCrouched(!this.playerStats.isCrouched);
  }

  public setSprinting(sprint: boolean) {
    this.playerStats.isSprinting = sprint;
    if (sprint) {
      this.playerStats.isCrouched = false;
      this.playerStats.isAiming = false;
    }
    this.notifyStats();
  }

  public reload() {
    const currentWeaponType = this.inventory.weapons[this.inventory.currentWeaponIndex];
    const ammoData = this.inventory.ammo[currentWeaponType];
    const config = WEAPON_CONFIGS[currentWeaponType];

    if (ammoData.currentMag >= config.magSize || ammoData.reserve <= 0 || this.playerStats.isReloading) {
      return;
    }

    this.playerStats.isReloading = true;
    this.reloadTimer = config.reloadTime;
    soundManager.playReload();
    this.notifyStats();
  }

  public jump() {
    if (this.isGrounded && !this.playerStats.isDead) {
      this.playerVelocity.y = 5.2;
      this.isGrounded = false;
      soundManager.playFootstep();
    }
  }

  public throwGrenade() {
    if (this.inventory.grenadesCount <= 0 || this.playerStats.isDead) return;

    this.inventory.grenadesCount--;
    soundManager.playButtonClick();

    const grenadeMesh = createWeaponMesh('grenade');
    const startPos = this.playerPosition.clone().add(new THREE.Vector3(0, 1.4, 0));
    grenadeMesh.position.copy(startPos);
    this.scene.add(grenadeMesh);

    // Direction from camera
    const throwDir = new THREE.Vector3();
    this.camera.getWorldDirection(throwDir);
    throwDir.y += 0.25; // upward arc
    throwDir.normalize();

    this.grenades.push({
      mesh: grenadeMesh,
      position: startPos,
      velocity: throwDir.multiplyScalar(16),
      fuseTimer: 2.2,
    });

    this.notifyStats();
  }

  // --- CONTROLS INPUT ---
  public setMoveVector(x: number, y: number) {
    this.inputMove.set(x, y);
  }

  public applyLookDelta(dx: number, dy: number) {
    const sens = this.settings.lookSensitivity * 0.0035;
    this.playerRotation -= dx * sens;
    const inv = this.settings.invertY ? -1 : 1;
    this.cameraPitch = Math.max(-0.6, Math.min(0.85, this.cameraPitch + dy * sens * inv));
  }

  // --- WEAPON SHOOTING LOGIC ---
  private fireCurrentWeapon() {
    const currentWeaponType = this.inventory.weapons[this.inventory.currentWeaponIndex];
    const ammoData = this.inventory.ammo[currentWeaponType];
    const config = WEAPON_CONFIGS[currentWeaponType];

    if (this.playerStats.isReloading) return;

    if (ammoData.currentMag <= 0) {
      this.reload();
      return;
    }

    // Consume ammo
    ammoData.currentMag--;
    this.fireTimer = 1.0 / config.fireRate;
    this.playerStats.shotsFired++;

    // Audio & Muzzle Flash
    soundManager.playGunshot(currentWeaponType as 'rifle' | 'pistol' | 'smg' | 'shotgun' | 'sniper');
    if (this.settings.hapticsEnabled && navigator.vibrate) {
      navigator.vibrate(25);
    }

    // World position of weapon muzzle
    const muzzlePos = new THREE.Vector3();
    this.playerRig.weaponMount.getWorldPosition(muzzlePos);
    muzzlePos.add(new THREE.Vector3(0, 0.05, 0.4));

    // Camera ray direction with spread & recoil
    const spreadVal = this.playerStats.isAiming ? config.spread * 0.35 : this.playerStats.isCrouched ? config.spread * 0.6 : config.spread;
    const pellets = config.pelletCount || 1;

    for (let p = 0; p < pellets; p++) {
      const spreadX = (Math.random() - 0.5) * spreadVal;
      const spreadY = (Math.random() - 0.5) * spreadVal;

      const shootDir = new THREE.Vector3();
      this.camera.getWorldDirection(shootDir);
      shootDir.x += spreadX;
      shootDir.y += spreadY;
      shootDir.normalize();

      // Camera view center origin
      const rayOrigin = this.camera.position.clone();
      const raycaster = new THREE.Raycaster(rayOrigin, shootDir, 0.1, config.range);

      // Perform raycast against enemies, barrels, and world
      this.performBulletRaycast(rayOrigin, shootDir, config.damage, muzzlePos);
    }

    // Recoil kick to camera pitch & arm
    this.cameraPitch += config.recoil * (this.playerStats.isAiming ? 0.4 : 1.0);
    this.playerRig.weaponMount.rotation.x -= 0.18;

    this.particles.triggerMuzzleFlash(muzzlePos, this.camera.getWorldDirection(new THREE.Vector3()));
    this.notifyStats();
  }

  private performBulletRaycast(origin: THREE.Vector3, direction: THREE.Vector3, baseDamage: number, muzzlePos: THREE.Vector3) {
    let closestDist = 120;
    let hitPoint = origin.clone().addScaledVector(direction, closestDist);
    let hitEnemy: EnemyEntity | null = null;
    let isHeadshot = false;

    // Check all living enemies
    for (const enemy of this.enemies) {
      if (enemy.isDead) continue;

      const enemyPos = enemy.position.clone().add(new THREE.Vector3(0, 0.9, 0));
      const dist = enemyPos.distanceTo(origin);
      if (dist > closestDist) continue;

      // Simple cylinder/box check
      const toEnemy = enemyPos.clone().sub(origin);
      const projection = toEnemy.dot(direction);

      if (projection > 0 && projection < closestDist) {
        const closestPointOnRay = origin.clone().addScaledVector(direction, projection);
        const distanceToCenter = closestPointOnRay.distanceTo(enemyPos);

        const hitRadius = enemy.isBoss ? 0.9 : 0.65;
        if (distanceToCenter < hitRadius) {
          closestDist = projection;
          hitPoint = closestPointOnRay;
          hitEnemy = enemy;
          // Check if headshot (hit near top)
          if (closestPointOnRay.y > enemy.position.y + 1.4) {
            isHeadshot = true;
          }
        }
      }
    }

    // Check explosive barrels and crates
    for (const prop of this.worldProps) {
      if (prop.isDestroyed || prop.type !== 'barrel') continue;
      const bPos = prop.mesh.position.clone().add(new THREE.Vector3(0, 0.55, 0));
      const toProp = bPos.clone().sub(origin);
      const proj = toProp.dot(direction);
      if (proj > 0 && proj < closestDist) {
        const point = origin.clone().addScaledVector(direction, proj);
        if (point.distanceTo(bPos) < 0.5) {
          closestDist = proj;
          hitPoint = point;
          prop.hp = (prop.hp || 20) - baseDamage;
          this.particles.triggerImpact(hitPoint, false);
          if (prop.hp <= 0) {
            this.detonateBarrel(prop);
          }
        }
      }
    }

    // Check Comms Radar if Mission 3
    if (this.mission.id === 3) {
      for (const prop of this.worldProps) {
        if (prop.isDestroyed || prop.type !== 'radar') continue;
        const rPos = prop.mesh.position.clone().add(new THREE.Vector3(0, 2.5, 0));
        const toR = rPos.clone().sub(origin);
        const proj = toR.dot(direction);
        if (proj > 0 && proj < closestDist) {
          const pt = origin.clone().addScaledVector(direction, proj);
          if (pt.distanceTo(rPos) < 1.8) {
            closestDist = proj;
            hitPoint = pt;
            prop.hp = (prop.hp || 120) - baseDamage;
            this.particles.triggerImpact(hitPoint, false);
            if (prop.hp <= 0) {
              prop.isDestroyed = true;
              this.particles.triggerExplosion(rPos, 1.6);
              soundManager.playExplosion();
              this.advanceObjective('m3_obj1');
            }
          }
        }
      }
    }

    // Bullet Tracer Visual
    this.particles.createTracer(muzzlePos, hitPoint);

    if (hitEnemy) {
      this.playerStats.shotsHit++;
      const finalDmg = isHeadshot ? baseDamage * 2.2 : baseDamage;
      hitEnemy.hp -= finalDmg;

      this.particles.triggerImpact(hitPoint, true);
      soundManager.playHitMarker();
      soundManager.playEnemyHurt();

      if (this.onHitFeedback) {
        this.onHitFeedback(isHeadshot);
      }

      // Alert enemy and nearby comrades
      hitEnemy.state = 'attack';
      hitEnemy.alertTimer = 6;
      this.alertNearbyEnemies(hitEnemy.position, 25);

      if (hitEnemy.hp <= 0 && !hitEnemy.isDead) {
        this.killEnemy(hitEnemy, isHeadshot);
      }
    } else {
      this.particles.triggerImpact(hitPoint, false);
    }
  }

  private alertNearbyEnemies(center: THREE.Vector3, radius: number) {
    for (const enemy of this.enemies) {
      if (!enemy.isDead && enemy.position.distanceTo(center) < radius) {
        enemy.state = 'attack';
        enemy.alertTimer = 8;
      }
    }
  }

  private detonateBarrel(barrelProp: WorldProp) {
    barrelProp.isDestroyed = true;
    const blastPos = barrelProp.mesh.position.clone().add(new THREE.Vector3(0, 0.6, 0));
    this.particles.triggerExplosion(blastPos, 2.0);
    soundManager.playExplosion();
    this.scene.remove(barrelProp.mesh);

    // Damage enemies in blast radius
    for (const enemy of this.enemies) {
      if (enemy.isDead) continue;
      const d = enemy.position.distanceTo(blastPos);
      if (d < 7.5) {
        const falloff = 1 - d / 7.5;
        enemy.hp -= 200 * falloff;
        if (enemy.hp <= 0) {
          this.killEnemy(enemy, false);
        }
      }
    }

    // Damage player if close
    const pDist = this.playerPosition.distanceTo(blastPos);
    if (pDist < 8.0) {
      const dmg = 80 * (1 - pDist / 8.0);
      this.damagePlayer(dmg);
    }

    // Optional objective for M1 or M3
    this.advanceObjective('m1_obj2');
    this.advanceObjective('m3_obj2');
  }

  private killEnemy(enemy: EnemyEntity, isHeadshot: boolean) {
    enemy.isDead = true;
    enemy.state = 'dead';
    this.playerStats.kills++;
    if (isHeadshot) this.playerStats.headshots++;
    this.playerStats.score += isHeadshot ? 150 : 100;

    // Ragdoll collapse animation: tilt and lower
    enemy.rig.root.rotation.x = -Math.PI / 2.2;
    enemy.rig.root.position.y = 0.2;

    // Drop ammo or health kit at enemy location
    if (Math.random() > 0.4) {
      const isMed = Math.random() > 0.6;
      const crate = createSupplyCrate(isMed);
      crate.position.copy(enemy.position);
      this.scene.add(crate);
      this.worldProps.push({
        type: 'crate',
        mesh: crate,
        box: new THREE.Box3().setFromObject(crate),
        isDestroyed: false,
      });
    }

    // Check mission objectives
    this.advanceObjective('m1_obj1');
    this.advanceObjective('m2_obj1');
    this.advanceObjective('m2_obj3');
    this.advanceObjective('m3_obj3');
    this.advanceObjective('m5_obj2');

    if (enemy.isBoss) {
      this.advanceObjective('m5_obj3');
    }

    // Mission 4 Waves
    if (this.mission.id === 4) {
      this.advanceObjective(`m4_wave${this.currentWave}`);
      this.waveEnemiesSpawned++;
      if (this.waveEnemiesSpawned >= 6 && this.currentWave < 4) {
        this.currentWave++;
        this.waveEnemiesSpawned = 0;
        soundManager.playObjectiveComplete();
      }
    }

    this.checkMissionStatus();
    this.notifyStats();
  }

  public damagePlayer(amount: number) {
    if (this.playerStats.isDead) return;

    soundManager.playPlayerHurt();
    if (this.settings.hapticsEnabled && navigator.vibrate) {
      navigator.vibrate([40, 20, 60]);
    }

    // Armor absorbs 70% of damage
    if (this.playerStats.armor > 0) {
      const absorbed = Math.min(this.playerStats.armor, amount * 0.7);
      this.playerStats.armor -= absorbed;
      amount -= absorbed;
    }

    this.playerStats.hp -= amount;

    if (this.playerStats.hp <= 0) {
      this.playerStats.hp = 0;
      this.playerStats.isDead = true;
      this.isGameOver = true;
      soundManager.playDefeat();
      soundManager.stopMusic();

      if (this.onMissionCompleted) {
        this.onMissionCompleted(false, this.playerStats);
      }
    }

    this.notifyStats();
  }

  // --- OBJECTIVES & WIN CONDITIONS ---
  private advanceObjective(objId: string) {
    const obj = this.mission.objectives.find((o) => o.id === objId);
    if (obj && !obj.completed) {
      obj.current++;
      if (obj.current >= obj.target) {
        obj.completed = true;
        soundManager.playObjectiveComplete();
      }
      if (this.onMissionObjectiveUpdated) {
        this.onMissionObjectiveUpdated(this.mission);
      }
      this.checkMissionStatus();
    }
  }

  private checkMissionStatus() {
    const primaryObjectives = this.mission.objectives.filter((o) => !o.optional);
    const allCompleted = primaryObjectives.every((o) => o.completed);

    if (allCompleted && !this.isVictory && !this.playerStats.isDead) {
      this.isVictory = true;
      this.playerStats.score += this.mission.xpReward;
      soundManager.playVictory();
      soundManager.stopMusic();

      if (this.onMissionCompleted) {
        this.onMissionCompleted(true, this.playerStats);
      }
    }
  }

  // --- MAIN LOOP ---
  private startLoop() {
    const tick = () => {
      if (this.isDestroyed) return;

      const delta = Math.min(this.clock.getDelta(), 0.1);

      if (!this.isPaused && !this.playerStats.isDead) {
        this.updatePlayer(delta);
        this.updateEnemies(delta);
        this.updateGrenades(delta);
        this.checkCratePickups();
        this.particles.update(delta);
      }

      this.updateCamera(delta);
      this.renderer.render(this.scene, this.camera);

      this.animFrameId = requestAnimationFrame(tick);
    };

    this.animFrameId = requestAnimationFrame(tick);
  }

  // --- PLAYER UPDATE ---
  private updatePlayer(delta: number) {
    // Weapons Timers
    if (this.fireTimer > 0) {
      this.fireTimer -= delta;
    }

    if (this.isFiring && this.fireTimer <= 0) {
      this.fireCurrentWeapon();
    }

    // Reload timer
    if (this.playerStats.isReloading) {
      this.reloadTimer -= delta;
      if (this.reloadTimer <= 0) {
        this.playerStats.isReloading = false;
        const currentWeaponType = this.inventory.weapons[this.inventory.currentWeaponIndex];
        const ammoData = this.inventory.ammo[currentWeaponType];
        const config = WEAPON_CONFIGS[currentWeaponType];
        const needed = config.magSize - ammoData.currentMag;
        const toAdd = Math.min(needed, ammoData.reserve);
        ammoData.currentMag += toAdd;
        ammoData.reserve -= toAdd;
        this.notifyStats();
      }
    }

    // Weapon mount spring recovery from recoil
    this.playerRig.weaponMount.rotation.x = THREE.MathUtils.damp(this.playerRig.weaponMount.rotation.x, -Math.PI / 12, 12, delta);

    // Movement calculation
    let moveSpeed = 4.2;
    if (this.playerStats.isSprinting) moveSpeed = 7.5;
    if (this.playerStats.isCrouched) moveSpeed = 2.4;
    if (this.playerStats.isAiming) moveSpeed = 2.8;

    // Movement vectors relative to player rotation
    const forward = new THREE.Vector3(0, 0, -1).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.playerRotation);
    const right = new THREE.Vector3(1, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.playerRotation);

    const moveDirection = new THREE.Vector3()
      .addScaledVector(forward, this.inputMove.y)
      .addScaledVector(right, this.inputMove.x);

    if (moveDirection.lengthSq() > 0.01) {
      moveDirection.normalize();
      this.playerPosition.addScaledVector(moveDirection, moveSpeed * delta);

      // Walk animation cycle
      this.walkCycle += delta * (this.playerStats.isSprinting ? 14 : 9);
      this.playerRig.leftLeg.rotation.x = Math.sin(this.walkCycle) * 0.6;
      this.playerRig.rightLeg.rotation.x = -Math.sin(this.walkCycle) * 0.6;
      this.playerRig.leftArm.rotation.x = -Math.sin(this.walkCycle) * 0.4;

      // Footstep sound
      if (Math.sin(this.walkCycle) > 0.95) {
        soundManager.playFootstep();
      }
    } else {
      // Idle breathing
      this.walkCycle += delta * 2;
      this.playerRig.leftLeg.rotation.x = THREE.MathUtils.damp(this.playerRig.leftLeg.rotation.x, 0, 8, delta);
      this.playerRig.rightLeg.rotation.x = THREE.MathUtils.damp(this.playerRig.rightLeg.rotation.x, 0, 8, delta);
      this.playerRig.torso.position.y = 0.3 + Math.sin(this.walkCycle) * 0.02;
    }

    // Gravity & Ground
    this.playerVelocity.y -= 14 * delta;
    this.playerPosition.y += this.playerVelocity.y * delta;
    if (this.playerPosition.y <= 0) {
      this.playerPosition.y = 0;
      this.playerVelocity.y = 0;
      this.isGrounded = true;
    }

    // Crouch stance height
    const targetY = this.playerStats.isCrouched ? -0.35 : 0;
    this.playerRig.root.position.copy(this.playerPosition);
    this.playerRig.root.position.y += targetY;
    this.playerRig.root.rotation.y = this.playerRotation;

    // Check boundary triggers for Checkpoints
    if (this.mission.id === 1 && this.playerPosition.z < -75) {
      this.advanceObjective('m1_obj3');
    }
    if (this.mission.id === 2 && this.playerPosition.z < -40) {
      this.advanceObjective('m2_obj2');
    }
    if (this.mission.id === 5 && this.playerPosition.z < -25) {
      this.advanceObjective('m5_obj1');
    }
  }

  // --- ENEMY AI UPDATE ---
  private updateEnemies(delta: number) {
    for (const enemy of this.enemies) {
      if (enemy.isDead) continue;

      const distToPlayer = enemy.position.distanceTo(this.playerPosition);

      // Detection
      if (distToPlayer < 35) {
        enemy.state = 'attack';
        enemy.alertTimer = 6;
      }

      if (enemy.state === 'attack') {
        // Face player
        const dirToPlayer = this.playerPosition.clone().sub(enemy.position);
        dirToPlayer.y = 0;
        enemy.rotation = Math.atan2(dirToPlayer.x, dirToPlayer.z);
        enemy.rig.root.rotation.y = enemy.rotation;

        // Move towards player if too far
        const idealDist = enemy.type === 'shotgunner' ? 8 : enemy.type === 'sniper' ? 45 : 18;
        if (distToPlayer > idealDist) {
          const forward = dirToPlayer.clone().normalize();
          enemy.position.addScaledVector(forward, 2.8 * delta);
        }

        // Enemy firing
        enemy.attackCooldown -= delta;
        if (enemy.attackCooldown <= 0 && distToPlayer < 50) {
          this.enemyFire(enemy);
          enemy.burstCount++;
          if (enemy.burstCount >= (enemy.type === 'sniper' ? 1 : 3)) {
            enemy.burstCount = 0;
            enemy.attackCooldown = enemy.type === 'boss' ? 0.8 : 1.8 + Math.random() * 1.2;
          } else {
            enemy.attackCooldown = 0.14; // rapid burst
          }
        }
      } else {
        // Patrol walk
        const dirToPatrol = enemy.patrolTarget.clone().sub(enemy.position);
        if (dirToPatrol.length() > 0.5) {
          dirToPatrol.normalize();
          enemy.position.addScaledVector(dirToPatrol, 1.2 * delta);
          enemy.rotation = Math.atan2(dirToPatrol.x, dirToPatrol.z);
          enemy.rig.root.rotation.y = enemy.rotation;
        } else {
          // New random patrol target
          enemy.patrolTarget.set(
            enemy.position.x + (Math.random() - 0.5) * 12,
            0,
            enemy.position.z + (Math.random() - 0.5) * 12
          );
        }
      }

      enemy.rig.root.position.copy(enemy.position);
    }
  }

  private enemyFire(enemy: EnemyEntity) {
    soundManager.playGunshot(enemy.weapon as 'rifle' | 'pistol' | 'smg' | 'shotgun' | 'sniper');

    const muzzle = enemy.position.clone().add(new THREE.Vector3(0, 1.1, 0));
    const target = this.playerPosition.clone().add(new THREE.Vector3(0, 1.0, 0));

    // Enemy aim inaccuracy
    const spread = enemy.type === 'sniper' ? 0.04 : 0.18;
    target.x += (Math.random() - 0.5) * spread * 10;
    target.y += (Math.random() - 0.5) * spread * 8;
    target.z += (Math.random() - 0.5) * spread * 10;

    this.particles.createTracer(muzzle, target);

    // Hit check against player
    const dist = enemy.position.distanceTo(this.playerPosition);
    const hitChance = Math.max(0.2, 0.7 - dist * 0.015);

    if (Math.random() < hitChance) {
      let dmg = 12;
      if (enemy.type === 'shotgunner') dmg = 24;
      if (enemy.type === 'sniper') dmg = 38;
      if (enemy.type === 'boss') dmg = 18;
      this.damagePlayer(dmg);
    }
  }

  // --- GRENADE PHYSICS ---
  private updateGrenades(delta: number) {
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const g = this.grenades[i];
      g.fuseTimer -= delta;

      g.velocity.y -= 14 * delta; // gravity
      g.position.addScaledVector(g.velocity, delta);
      g.mesh.position.copy(g.position);
      g.mesh.rotation.x += delta * 8;
      g.mesh.rotation.y += delta * 6;

      // Bounce on ground
      if (g.position.y <= 0.1) {
        g.position.y = 0.1;
        g.velocity.y *= -0.5;
        g.velocity.x *= 0.7;
        g.velocity.z *= 0.7;
      }

      // Detonation
      if (g.fuseTimer <= 0) {
        this.detonateGrenade(g);
        this.scene.remove(g.mesh);
        this.grenades.splice(i, 1);
      }
    }
  }

  private detonateGrenade(g: GrenadeEntity) {
    this.particles.triggerExplosion(g.position, 2.2);
    soundManager.playExplosion();

    // Radial damage
    for (const enemy of this.enemies) {
      if (enemy.isDead) continue;
      const dist = enemy.position.distanceTo(g.position);
      if (dist < 9.0) {
        const dmg = 220 * (1 - dist / 9.0);
        enemy.hp -= dmg;
        if (enemy.hp <= 0) {
          this.killEnemy(enemy, false);
        }
      }
    }

    // Detonate nearby barrels
    for (const prop of this.worldProps) {
      if (prop.isDestroyed || prop.type !== 'barrel') continue;
      if (prop.mesh.position.distanceTo(g.position) < 6.0) {
        this.detonateBarrel(prop);
      }
    }
  }

  // --- CRATE PICKUPS ---
  private checkCratePickups() {
    for (const prop of this.worldProps) {
      if (prop.isDestroyed || prop.type !== 'crate') continue;
      if (prop.mesh.position.distanceTo(this.playerPosition) < 2.0) {
        prop.isDestroyed = true;
        this.scene.remove(prop.mesh);

        // Pick up health or ammo
        if (this.playerStats.hp < 100) {
          this.playerStats.hp = Math.min(100, this.playerStats.hp + 40);
        } else {
          this.playerStats.armor = Math.min(100, this.playerStats.armor + 50);
        }

        // Refill current weapon reserve
        const currentWeaponType = this.inventory.weapons[this.inventory.currentWeaponIndex];
        const config = WEAPON_CONFIGS[currentWeaponType];
        this.inventory.ammo[currentWeaponType].reserve = Math.min(
          config.maxReserveAmmo,
          this.inventory.ammo[currentWeaponType].reserve + config.magSize * 2
        );

        soundManager.playButtonClick();
        this.notifyStats();
      }
    }
  }

  // --- CAMERA UPDATE ---
  private updateCamera(delta: number) {
    const currentWeaponType = this.inventory.weapons[this.inventory.currentWeaponIndex];
    const config = WEAPON_CONFIGS[currentWeaponType];

    // FOV Aim Zoom
    const targetFov = this.playerStats.isAiming ? config.zoomFov : 65;
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 12, delta);
    this.camera.updateProjectionMatrix();

    // Shoulder Offset
    const shoulderOffset = this.playerStats.isAiming ? 0.65 : 0.85;
    const targetHeight = this.playerStats.isCrouched ? 1.2 : 1.7;

    // Target point right above character head
    this.cameraTarget.copy(this.playerPosition).add(new THREE.Vector3(0, targetHeight, 0));

    // Desired camera distance
    const targetDist = this.playerStats.isAiming ? 1.8 : this.cameraDistance;

    // Spherical position from rotation & pitch
    const camOffset = new THREE.Vector3(
      Math.sin(this.playerRotation) * Math.cos(this.cameraPitch) * targetDist,
      Math.sin(this.cameraPitch) * targetDist,
      Math.cos(this.playerRotation) * Math.cos(this.cameraPitch) * targetDist
    );

    // Apply right shoulder offset
    const right = new THREE.Vector3(1, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.playerRotation);
    camOffset.addScaledVector(right, shoulderOffset);

    const desiredCamPos = this.cameraTarget.clone().add(camOffset);
    this.camera.position.lerp(desiredCamPos, 0.22);
    this.camera.lookAt(this.cameraTarget.clone().addScaledVector(right, shoulderOffset * 0.5));
  }

  // --- RESIZE ---
  public handleResize() {
    if (!this.canvasContainer || this.isDestroyed) return;
    const w = this.canvasContainer.clientWidth;
    const h = this.canvasContainer.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  // --- STATS NOTIFICATION ---
  private notifyStats() {
    if (this.onStatsChanged) {
      this.onStatsChanged({ ...this.playerStats }, { ...this.inventory });
    }
  }

  // --- CLEANUP ---
  public destroy() {
    this.isDestroyed = true;
    cancelAnimationFrame(this.animFrameId);
    soundManager.stopMusic();
    this.particles.cleanup();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
