/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { WeaponType } from '../types/game';

// Helper to create procedural Canvas textures for tactical camo, asphalt, concrete & hazard stripes
function createAsphaltTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#22252a';
  ctx.fillRect(0, 0, 512, 512);

  // Grain & noise
  for (let i = 0; i < 4000; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const gray = Math.floor(25 + Math.random() * 25);
    ctx.fillStyle = `rgb(${gray},${gray},${gray})`;
    ctx.fillRect(x, y, 2, 2);
  }
  // Road dashed markings
  ctx.fillStyle = '#c8a832';
  for (let y = 30; y < 512; y += 80) {
    ctx.fillRect(250, y, 12, 45);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createHazardTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#d92222';
  ctx.fillRect(0, 0, 256, 256);
  ctx.fillStyle = '#111111';
  // Diagonal warning stripes
  for (let i = -256; i < 512; i += 40) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i + 20, 0);
    ctx.lineTo(i + 20 + 256, 256);
    ctx.lineTo(i + 256, 256);
    ctx.fill();
  }
  // Skull or "DANGER FLAMMABLE" symbol
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 24px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('EXPLOSIVE', 128, 135);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// Reusable procedural materials
export const materials = {
  playerUniform: new THREE.MeshStandardMaterial({ color: 0x3d4b3c, roughness: 0.8, metalness: 0.1 }), // Olive camo
  playerVest: new THREE.MeshStandardMaterial({ color: 0x1f2421, roughness: 0.7, metalness: 0.2 }),
  playerSkin: new THREE.MeshStandardMaterial({ color: 0xc89674, roughness: 0.6, metalness: 0.05 }),
  playerHelmet: new THREE.MeshStandardMaterial({ color: 0x2b382d, roughness: 0.5, metalness: 0.4 }),
  visor: new THREE.MeshStandardMaterial({ color: 0x00ffee, roughness: 0.2, metalness: 0.9, emissive: 0x003322 }),

  enemyUniform: new THREE.MeshStandardMaterial({ color: 0x483232, roughness: 0.85, metalness: 0.1 }), // Urban crimson rogue
  enemyVest: new THREE.MeshStandardMaterial({ color: 0x241d1d, roughness: 0.75, metalness: 0.2 }),
  enemyHelmet: new THREE.MeshStandardMaterial({ color: 0x2a1e1e, roughness: 0.5, metalness: 0.4 }),
  enemyVisor: new THREE.MeshStandardMaterial({ color: 0xff2222, roughness: 0.2, metalness: 0.9, emissive: 0x550000 }),

  bossArmor: new THREE.MeshStandardMaterial({ color: 0x1a1a24, roughness: 0.4, metalness: 0.7 }),
  bossGoldTrim: new THREE.MeshStandardMaterial({ color: 0xd4af37, roughness: 0.3, metalness: 0.85 }),

  gunMetal: new THREE.MeshStandardMaterial({ color: 0x1e2022, roughness: 0.3, metalness: 0.85 }),
  gunPolymer: new THREE.MeshStandardMaterial({ color: 0x282a2e, roughness: 0.8, metalness: 0.1 }),
  gunGold: new THREE.MeshStandardMaterial({ color: 0xdfb140, roughness: 0.3, metalness: 0.9 }),
  gunWood: new THREE.MeshStandardMaterial({ color: 0x5c3a21, roughness: 0.7, metalness: 0.05 }),

  concrete: new THREE.MeshStandardMaterial({ color: 0x7a8089, roughness: 0.9, metalness: 0.05 }),
  concreteDark: new THREE.MeshStandardMaterial({ color: 0x4d535e, roughness: 0.92, metalness: 0.05 }),
  asphalt: new THREE.MeshStandardMaterial({ map: createAsphaltTexture(), roughness: 0.85, metalness: 0.1 }),
  dirt: new THREE.MeshStandardMaterial({ color: 0x42382c, roughness: 0.95, metalness: 0.02 }),
  sandbags: new THREE.MeshStandardMaterial({ color: 0x8f7d5b, roughness: 0.9, metalness: 0.05 }),
  woodCrate: new THREE.MeshStandardMaterial({ color: 0x6e5132, roughness: 0.85, metalness: 0.05 }),
  explosiveBarrel: new THREE.MeshStandardMaterial({ map: createHazardTexture(), roughness: 0.4, metalness: 0.5 }),
  metalRust: new THREE.MeshStandardMaterial({ color: 0x55443d, roughness: 0.7, metalness: 0.6 }),
  glass: new THREE.MeshStandardMaterial({ color: 0x88ccff, roughness: 0.1, metalness: 0.9, transparent: true, opacity: 0.6 }),
  foliage: new THREE.MeshStandardMaterial({ color: 0x264423, roughness: 0.9, metalness: 0.0 }),
  bark: new THREE.MeshStandardMaterial({ color: 0x3d2b1f, roughness: 0.95, metalness: 0.05 }),
  rock: new THREE.MeshStandardMaterial({ color: 0x55585d, roughness: 0.9, metalness: 0.1 }),
};

export interface SoldierRig {
  root: THREE.Group;
  torso: THREE.Mesh;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  weaponMount: THREE.Group;
  muzzlePoint: THREE.Vector3;
}

// 1. Procedural 3D Soldier (Composite 3-12 parts)
export function createSoldier(isEnemy = false, isBoss = false): SoldierRig {
  const root = new THREE.Group();
  root.castShadow = true;

  const uniformMat = isBoss ? materials.bossArmor : isEnemy ? materials.enemyUniform : materials.playerUniform;
  const vestMat = isBoss ? materials.bossGoldTrim : isEnemy ? materials.enemyVest : materials.playerVest;
  const helmetMat = isBoss ? materials.bossArmor : isEnemy ? materials.enemyHelmet : materials.playerHelmet;
  const visorMat = isEnemy || isBoss ? materials.enemyVisor : materials.visor;

  const scale = isBoss ? 1.3 : 1.0;

  // Pelvis / Lower Body root
  const pelvis = new THREE.Group();
  pelvis.position.y = 0.9 * scale;
  root.add(pelvis);

  // Torso
  const torsoGeo = new THREE.BoxGeometry(0.48 * scale, 0.55 * scale, 0.3 * scale);
  const torso = new THREE.Mesh(torsoGeo, uniformMat);
  torso.position.y = 0.3 * scale;
  torso.castShadow = true;
  torso.receiveShadow = true;
  pelvis.add(torso);

  // Tactical Vest
  const vestGeo = new THREE.BoxGeometry(0.52 * scale, 0.44 * scale, 0.36 * scale);
  const vest = new THREE.Mesh(vestGeo, vestMat);
  vest.castShadow = true;
  torso.add(vest);

  // Vest Mag Pouches
  const pouchGeo = new THREE.BoxGeometry(0.12 * scale, 0.14 * scale, 0.08 * scale);
  for (let i = -1; i <= 1; i++) {
    const pouch = new THREE.Mesh(pouchGeo, vestMat);
    pouch.position.set(i * 0.14 * scale, -0.08 * scale, 0.2 * scale);
    torso.add(pouch);
  }

  // Radio on shoulder
  const radioGeo = new THREE.BoxGeometry(0.08 * scale, 0.18 * scale, 0.08 * scale);
  const radio = new THREE.Mesh(radioGeo, materials.gunMetal);
  radio.position.set(-0.2 * scale, 0.22 * scale, 0.1 * scale);
  torso.add(radio);

  // Head group
  const head = new THREE.Group();
  head.position.y = 0.38 * scale;
  torso.add(head);

  // Face
  const faceGeo = new THREE.BoxGeometry(0.24 * scale, 0.24 * scale, 0.24 * scale);
  const face = new THREE.Mesh(faceGeo, materials.playerSkin);
  face.castShadow = true;
  head.add(face);

  // Helmet
  const helmetGeo = new THREE.BoxGeometry(0.28 * scale, 0.18 * scale, 0.28 * scale);
  const helmet = new THREE.Mesh(helmetGeo, helmetMat);
  helmet.position.y = 0.08 * scale;
  helmet.castShadow = true;
  head.add(helmet);

  // Tactical Visor / NVG
  const visorGeo = new THREE.BoxGeometry(0.22 * scale, 0.07 * scale, 0.08 * scale);
  const visor = new THREE.Mesh(visorGeo, visorMat);
  visor.position.set(0, 0.02 * scale, 0.14 * scale);
  head.add(visor);

  // Left Arm
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.32 * scale, 0.22 * scale, 0);
  torso.add(leftArm);
  const armGeo = new THREE.BoxGeometry(0.14 * scale, 0.5 * scale, 0.14 * scale);
  armGeo.translate(0, -0.22 * scale, 0);
  const leftArmMesh = new THREE.Mesh(armGeo, uniformMat);
  leftArmMesh.castShadow = true;
  leftArm.add(leftArmMesh);

  // Right Arm (Weapon holding arm)
  const rightArm = new THREE.Group();
  rightArm.position.set(0.32 * scale, 0.22 * scale, 0);
  torso.add(rightArm);
  const rightArmMesh = new THREE.Mesh(armGeo, uniformMat);
  rightArmMesh.castShadow = true;
  rightArm.add(rightArmMesh);

  // Weapon mount socket attached to right hand
  const weaponMount = new THREE.Group();
  weaponMount.position.set(0.05 * scale, -0.42 * scale, 0.18 * scale);
  weaponMount.rotation.x = -Math.PI / 12;
  rightArm.add(weaponMount);

  // Left Leg
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.16 * scale, 0, 0);
  pelvis.add(leftLeg);
  const legGeo = new THREE.BoxGeometry(0.18 * scale, 0.85 * scale, 0.2 * scale);
  legGeo.translate(0, -0.42 * scale, 0);
  const leftLegMesh = new THREE.Mesh(legGeo, uniformMat);
  leftLegMesh.castShadow = true;
  leftLeg.add(leftLegMesh);

  // Combat Boot Left
  const bootGeo = new THREE.BoxGeometry(0.19 * scale, 0.18 * scale, 0.26 * scale);
  const leftBoot = new THREE.Mesh(bootGeo, materials.playerVest);
  leftBoot.position.set(0, -0.8 * scale, 0.04 * scale);
  leftBoot.castShadow = true;
  leftLeg.add(leftBoot);

  // Right Leg
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.16 * scale, 0, 0);
  pelvis.add(rightLeg);
  const rightLegMesh = new THREE.Mesh(legGeo, uniformMat);
  rightLegMesh.castShadow = true;
  rightLeg.add(rightLegMesh);

  const rightBoot = new THREE.Mesh(bootGeo, materials.playerVest);
  rightBoot.position.set(0, -0.8 * scale, 0.04 * scale);
  rightBoot.castShadow = true;
  rightLeg.add(rightBoot);

  return {
    root,
    torso,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    weaponMount,
    muzzlePoint: new THREE.Vector3(0, 0.05 * scale, 0.85 * scale),
  };
}

// 2. 3D Weapon Models (Detailed, multi-part tactical firearms)
export function createWeaponMesh(type: WeaponType): THREE.Group {
  const group = new THREE.Group();

  switch (type) {
    case 'rifle': {
      // M4A1
      const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.1, 0.42), materials.gunMetal);
      receiver.castShadow = true;
      group.add(receiver);

      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.38, 8), materials.gunMetal);
      barrel.rotation.x = Math.PI / 2;
      barrel.position.set(0, 0.02, 0.38);
      group.add(barrel);

      const muzzleBrake = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.06, 8), materials.gunMetal);
      muzzleBrake.rotation.x = Math.PI / 2;
      muzzleBrake.position.set(0, 0.02, 0.58);
      group.add(muzzleBrake);

      const stock = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.12, 0.22), materials.gunPolymer);
      stock.position.set(0, -0.01, -0.3);
      group.add(stock);

      const mag = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.2, 0.09), materials.gunPolymer);
      mag.position.set(0, -0.12, 0.08);
      mag.rotation.x = 0.2;
      group.add(mag);

      const grip = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.14, 0.07), materials.gunPolymer);
      grip.position.set(0, -0.1, -0.1);
      grip.rotation.x = -0.35;
      group.add(grip);

      // Red-dot reflex sight
      const sight = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.06, 0.1), materials.gunMetal);
      sight.position.set(0, 0.08, 0.05);
      group.add(sight);
      break;
    }
    case 'pistol': {
      // M9
      const slide = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.06, 0.22), materials.gunMetal);
      slide.castShadow = true;
      group.add(slide);

      const grip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.13, 0.07), materials.gunPolymer);
      grip.position.set(0, -0.08, -0.05);
      grip.rotation.x = -0.3;
      group.add(grip);
      break;
    }
    case 'smg': {
      // MP5
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.09, 0.32), materials.gunMetal);
      body.castShadow = true;
      group.add(body);

      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.2, 8), materials.gunMetal);
      barrel.rotation.x = Math.PI / 2;
      barrel.position.set(0, 0.01, 0.25);
      group.add(barrel);

      const curvedMag = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.18, 0.07), materials.gunMetal);
      curvedMag.position.set(0, -0.12, 0.06);
      curvedMag.rotation.x = 0.35;
      group.add(curvedMag);

      const grip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.13, 0.06), materials.gunPolymer);
      grip.position.set(0, -0.09, -0.08);
      grip.rotation.x = -0.3;
      group.add(grip);
      break;
    }
    case 'shotgun': {
      // SPAS-12
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.1, 0.45), materials.gunMetal);
      body.castShadow = true;
      group.add(body);

      const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.4, 8), materials.gunMetal);
      barrel.rotation.x = Math.PI / 2;
      barrel.position.set(0, 0.02, 0.42);
      group.add(barrel);

      const pump = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.16, 8), materials.gunPolymer);
      pump.rotation.x = Math.PI / 2;
      pump.position.set(0, -0.02, 0.3);
      group.add(pump);
      break;
    }
    case 'sniper': {
      // AWM
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.1, 0.65), materials.gunMetal);
      body.castShadow = true;
      group.add(body);

      const longBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.65, 8), materials.gunMetal);
      longBarrel.rotation.x = Math.PI / 2;
      longBarrel.position.set(0, 0.02, 0.62);
      group.add(longBarrel);

      const muzzleBrake = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 0.08), materials.gunMetal);
      muzzleBrake.position.set(0, 0.02, 0.96);
      group.add(muzzleBrake);

      // Huge Sniper Scope
      const scopeTube = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.28, 12), materials.gunMetal);
      scopeTube.rotation.x = Math.PI / 2;
      scopeTube.position.set(0, 0.1, 0.08);
      group.add(scopeTube);

      const scopeLens = new THREE.Mesh(new THREE.CircleGeometry(0.025, 12), materials.visor);
      scopeLens.position.set(0, 0.1, 0.22);
      group.add(scopeLens);
      break;
    }
    case 'grenade': {
      // M67 Frag Grenade
      const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 12), materials.playerHelmet);
      sphere.castShadow = true;
      group.add(sphere);

      const pin = new THREE.Mesh(new THREE.TorusGeometry(0.02, 0.005, 6, 12), materials.gunMetal);
      pin.position.set(0, 0.07, 0);
      group.add(pin);
      break;
    }
  }

  return group;
}

// 3. Military Humvee (Abandoned armored vehicle)
export function createHumvee(): THREE.Group {
  const group = new THREE.Group();

  // Chassis
  const bodyGeo = new THREE.BoxGeometry(2.4, 1.2, 4.8);
  const body = new THREE.Mesh(bodyGeo, materials.playerUniform);
  body.position.y = 1.0;
  body.castShadow = true;
  body.receiveShadow = true;
  group.add(body);

  // Cabin roof
  const cabinGeo = new THREE.BoxGeometry(2.2, 0.8, 2.6);
  const cabin = new THREE.Mesh(cabinGeo, materials.playerVest);
  cabin.position.set(0, 1.9, -0.4);
  cabin.castShadow = true;
  group.add(cabin);

  // Windshield
  const glassGeo = new THREE.PlaneGeometry(1.9, 0.6);
  const windshield = new THREE.Mesh(glassGeo, materials.glass);
  windshield.position.set(0, 1.85, 0.92);
  windshield.rotation.x = -0.2;
  group.add(windshield);

  // Turret Ring on top
  const turretGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.3, 12);
  const turret = new THREE.Mesh(turretGeo, materials.gunMetal);
  turret.position.set(0, 2.45, -0.3);
  turret.castShadow = true;
  group.add(turret);

  // 4 Wheels
  const wheelGeo = new THREE.CylinderGeometry(0.48, 0.48, 0.35, 16);
  wheelGeo.rotateZ(Math.PI / 2);
  const wheelMat = materials.playerVest;

  const wheelPositions = [
    [-1.25, 0.48, 1.4],
    [1.25, 0.48, 1.4],
    [-1.25, 0.48, -1.4],
    [1.25, 0.48, -1.4],
  ];

  wheelPositions.forEach(([x, y, z]) => {
    const wheel = new THREE.Mesh(wheelGeo, wheelMat);
    wheel.position.set(x, y, z);
    wheel.castShadow = true;
    group.add(wheel);
  });

  return group;
}

// 4. Military Watchtower
export function createWatchtower(): THREE.Group {
  const group = new THREE.Group();

  // 4 Legs
  const legGeo = new THREE.CylinderGeometry(0.12, 0.14, 6.0, 8);
  const offsets = [
    [-1.4, -1.4],
    [1.4, -1.4],
    [-1.4, 1.4],
    [1.4, 1.4],
  ];

  offsets.forEach(([x, z]) => {
    const leg = new THREE.Mesh(legGeo, materials.metalRust);
    leg.position.set(x, 3.0, z);
    leg.castShadow = true;
    group.add(leg);
  });

  // Guard Platform
  const platGeo = new THREE.BoxGeometry(3.4, 0.25, 3.4);
  const plat = new THREE.Mesh(platGeo, materials.concreteDark);
  plat.position.y = 6.0;
  plat.castShadow = true;
  plat.receiveShadow = true;
  group.add(plat);

  // Railing
  const railGeo = new THREE.BoxGeometry(3.4, 0.9, 0.08);
  const r1 = new THREE.Mesh(railGeo, materials.metalRust);
  r1.position.set(0, 6.55, 1.65);
  const r2 = new THREE.Mesh(railGeo, materials.metalRust);
  r2.position.set(0, 6.55, -1.65);
  group.add(r1, r2);

  // Roof
  const roofGeo = new THREE.BoxGeometry(3.6, 0.2, 3.6);
  const roof = new THREE.Mesh(roofGeo, materials.playerVest);
  roof.position.y = 8.5;
  roof.castShadow = true;
  group.add(roof);

  // Roof supports
  offsets.forEach(([x, z]) => {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.4, 6), materials.metalRust);
    post.position.set(x * 0.95, 7.3, z * 0.95);
    group.add(post);
  });

  return group;
}

// 5. Urban Concrete Building / Bunker (Damaged military complex)
export function createBuilding(w: number, h: number, d: number): THREE.Group {
  const group = new THREE.Group();

  // Main structure
  const wallGeo = new THREE.BoxGeometry(w, h, d);
  const wall = new THREE.Mesh(wallGeo, materials.concrete);
  wall.position.y = h / 2;
  wall.castShadow = true;
  wall.receiveShadow = true;
  group.add(wall);

  // Roof rim
  const rimGeo = new THREE.BoxGeometry(w + 0.3, 0.4, d + 0.3);
  const rim = new THREE.Mesh(rimGeo, materials.concreteDark);
  rim.position.y = h + 0.2;
  rim.castShadow = true;
  group.add(rim);

  // Windows / embrasures
  const winMat = materials.glass;
  const numWinX = Math.max(1, Math.floor(w / 4));
  const numFloors = Math.max(1, Math.floor(h / 3.5));

  for (let f = 1; f <= numFloors; f++) {
    const y = f * 3.2 - 1.2;
    for (let x = 0; x < numWinX; x++) {
      const xPos = -w / 2 + (w / (numWinX + 1)) * (x + 1);
      // Front window
      const winFront = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.4), winMat);
      winFront.position.set(xPos, y, d / 2 + 0.02);
      group.add(winFront);

      // Back window
      const winBack = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.4), winMat);
      winBack.position.set(xPos, y, -d / 2 - 0.02);
      winBack.rotation.y = Math.PI;
      group.add(winBack);
    }
  }

  return group;
}

// 6. Explosive Red Barrel (Deals AOE blast when shot)
export function createExplosiveBarrel(): THREE.Group {
  const group = new THREE.Group();
  const geo = new THREE.CylinderGeometry(0.38, 0.38, 1.1, 14);
  const mesh = new THREE.Mesh(geo, materials.explosiveBarrel);
  mesh.position.y = 0.55;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  group.add(mesh);
  return group;
}

// 7. Tactical Ammo & Medical Supply Crate
export function createSupplyCrate(isMedical = false): THREE.Group {
  const group = new THREE.Group();
  const geo = new THREE.BoxGeometry(0.9, 0.6, 0.6);
  const mat = isMedical ? materials.playerVest : materials.woodCrate;
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.3;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  group.add(mesh);

  // Cross or Ammo stripe on top
  const iconGeo = new THREE.PlaneGeometry(0.3, 0.3);
  const iconMat = new THREE.MeshBasicMaterial({ color: isMedical ? 0x00ff88 : 0xffc800 });
  const icon = new THREE.Mesh(iconGeo, iconMat);
  icon.rotation.x = -Math.PI / 2;
  icon.position.set(0, 0.61, 0);
  group.add(icon);

  return group;
}

// 8. Sandbag Barrier
export function createSandbagBarrier(): THREE.Group {
  const group = new THREE.Group();
  const bagGeo = new THREE.BoxGeometry(0.8, 0.25, 0.4);

  // 3 stacked layers
  for (let row = 0; row < 3; row++) {
    const y = 0.125 + row * 0.24;
    const count = 3 - (row % 2 === 1 ? 1 : 0);
    const startX = count === 3 ? -0.8 : -0.4;
    for (let c = 0; c < count; c++) {
      const bag = new THREE.Mesh(bagGeo, materials.sandbags);
      bag.position.set(startX + c * 0.8, y, (Math.random() - 0.5) * 0.04);
      bag.rotation.y = (Math.random() - 0.5) * 0.1;
      bag.castShadow = true;
      bag.receiveShadow = true;
      group.add(bag);
    }
  }

  return group;
}

// 9. Comms Radar Dish & Antenna (Mission 3 objective)
export function createRadarDish(): THREE.Group {
  const group = new THREE.Group();

  // Generator base
  const base = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.2, 2.0), materials.metalRust);
  base.position.y = 0.6;
  base.castShadow = true;
  group.add(base);

  // Mast
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, 4.0, 8), materials.gunMetal);
  mast.position.y = 3.2;
  group.add(mast);

  // Parabolic dish
  const dishGeo = new THREE.SphereGeometry(1.4, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.4);
  const dish = new THREE.Mesh(dishGeo, materials.gunMetal);
  dish.position.set(0, 4.8, 0);
  dish.rotation.x = Math.PI * 0.6;
  dish.castShadow = true;
  group.add(dish);

  // Red blinking receiver probe
  const probe = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 8), new THREE.MeshBasicMaterial({ color: 0xff0044 }));
  probe.position.set(0, 5.2, 0.8);
  group.add(probe);

  return group;
}

// 10. Military Perimeter Tree
export function createTree(): THREE.Group {
  const group = new THREE.Group();

  // Trunk
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.35, 4.5, 8), materials.bark);
  trunk.position.y = 2.25;
  trunk.castShadow = true;
  group.add(trunk);

  // Foliage cones (pine/military spruce)
  const coneGeo1 = new THREE.ConeGeometry(2.2, 3.0, 8);
  const c1 = new THREE.Mesh(coneGeo1, materials.foliage);
  c1.position.y = 4.2;
  c1.castShadow = true;

  const coneGeo2 = new THREE.ConeGeometry(1.7, 2.6, 8);
  const c2 = new THREE.Mesh(coneGeo2, materials.foliage);
  c2.position.y = 5.6;
  c2.castShadow = true;

  const coneGeo3 = new THREE.ConeGeometry(1.2, 2.0, 8);
  const c3 = new THREE.Mesh(coneGeo3, materials.foliage);
  c3.position.y = 6.8;
  c3.castShadow = true;

  group.add(c1, c2, c3);
  return group;
}
