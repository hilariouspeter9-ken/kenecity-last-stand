/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MissionConfig } from '../types/game';

export const CAMPAIGN_MISSIONS: MissionConfig[] = [
  {
    id: 1,
    title: 'THE INVASION',
    codename: 'Operation Iron Dawn',
    location: 'Sector 4 Outskirts - Kenecity Perimeter',
    timeOfDay: 'day',
    difficulty: 'EASY',
    briefing: 'Hostile rogue PMC forces have breached Kenecity outer defenses. Deploy into the urban ruins, secure the forward perimeter checkpoint, and neutralize all enemy patrols.',
    objectives: [
      { id: 'm1_obj1', description: 'Neutralize Outpost Patrols', current: 0, target: 8, completed: false },
      { id: 'm1_obj2', description: 'Destroy Rogue Ammo Depots', current: 0, target: 2, completed: false, optional: true },
      { id: 'm1_obj3', description: 'Reach Forward Checkpoint Alpha', current: 0, target: 1, completed: false },
    ],
    xpReward: 350,
    enemyCount: 10,
    musicMood: 'tactical',
  },
  {
    id: 2,
    title: 'RESCUE OPERATION',
    codename: 'Operation Phantom Extraction',
    location: 'Kenecity Railway Warehouse Depot',
    timeOfDay: 'sunset',
    difficulty: 'MEDIUM',
    briefing: 'Allied Recon Captain Miller has been captured and is held inside a fortified holding cell in the railway depot. Infiltrate the perimeter, eliminate the elite prison guards, and extract the Captain.',
    objectives: [
      { id: 'm2_obj1', description: 'Clear Depot Gate Sentry Squad', current: 0, target: 6, completed: false },
      { id: 'm2_obj2', description: 'Locate Holding Cell & Unlock Security Terminal', current: 0, target: 1, completed: false },
      { id: 'm2_obj3', description: 'Eliminate Responding Breachers & Extract Miller', current: 0, target: 6, completed: false },
    ],
    xpReward: 600,
    enemyCount: 14,
    musicMood: 'stealth',
  },
  {
    id: 3,
    title: 'ENEMY TERRITORY',
    codename: 'Operation Blind Radar',
    location: 'Fortified Hilltop Command Base',
    timeOfDay: 'night',
    difficulty: 'HARD',
    briefing: 'The enemy has established an anti-air radar installation and electronic jamming uplink on the heights. Breach the perimeter wire, destroy the 3 comms satellite relays and fuel tanks, and wipe out the base garrison.',
    objectives: [
      { id: 'm3_obj1', description: 'Sabotage 3 Radar & Comms Power Relays', current: 0, target: 3, completed: false },
      { id: 'm3_obj2', description: 'Detonate Auxiliary Fuel Silo', current: 0, target: 1, completed: false },
      { id: 'm3_obj3', description: 'Neutralize Base Garrison Force', current: 0, target: 12, completed: false },
    ],
    xpReward: 950,
    enemyCount: 16,
    musicMood: 'combat',
  },
  {
    id: 4,
    title: 'LAST SURVIVOR',
    codename: 'Operation Citadel Stand',
    location: 'Outpost Bunker Delta - Kenecity Heart',
    timeOfDay: 'sunset',
    difficulty: 'EXTREME',
    briefing: 'Enemy forces have launched a full-scale counter-assault on Outpost Delta. Reinforcements are delayed by heavy artillery. Hold the line against 4 punishing waves of assault troops, shotgun breachers, and snipers.',
    objectives: [
      { id: 'm4_wave1', description: 'Repel Wave 1 - Advance Recon Squad', current: 0, target: 5, completed: false },
      { id: 'm4_wave2', description: 'Repel Wave 2 - Shotgun Breachers & Flankers', current: 0, target: 7, completed: false },
      { id: 'm4_wave3', description: 'Repel Wave 3 - Elite Sniper & Heavy Support', current: 0, target: 8, completed: false },
      { id: 'm4_wave4', description: 'Survive Final Overwhelming Assault', current: 0, target: 10, completed: false },
    ],
    xpReward: 1400,
    enemyCount: 30,
    musicMood: 'combat',
  },
  {
    id: 5,
    title: 'FINAL CONFRONTATION',
    codename: 'Operation Decapitation',
    location: 'Kenecity Citadel - Inner Sanctum',
    timeOfDay: 'night',
    difficulty: 'NIGHTMARE',
    briefing: 'This is the last stand for Kenecity. Rogue Supreme Commander General Victor Malenkov is coordinating the siege from the central fortified citadel. Infiltrate the courtyard, neutralize his elite death squad, and eliminate Malenkov once and for all.',
    objectives: [
      { id: 'm5_obj1', description: 'Breach Citadel Courtyard Barriers', current: 0, target: 1, completed: false },
      { id: 'm5_obj2', description: 'Eliminate General Malenkov Elite Bodyguards', current: 0, target: 8, completed: false },
      { id: 'm5_obj3', description: 'Defeat Commander General Victor Malenkov', current: 0, target: 1, completed: false },
    ],
    xpReward: 2500,
    enemyCount: 20,
    hasBoss: true,
    bossName: 'General Victor Malenkov',
    musicMood: 'boss',
  },
];
