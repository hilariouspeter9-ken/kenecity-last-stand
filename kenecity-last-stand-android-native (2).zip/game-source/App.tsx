/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import {
  GameSettings,
  MissionConfig,
  PlayerInventory,
  PlayerStats,
  UserProgression,
  WeaponType,
} from './types/game';
import { CAMPAIGN_MISSIONS } from './game/missions';
import { WEAPON_CONFIGS } from './game/weapons';
import { GameEngine } from './game/GameEngine';
import { HUD } from './components/HUD';
import { TouchControls } from './components/TouchControls';
import { MainMenu } from './components/MainMenu';
import { MissionsScreen } from './components/MissionsScreen';
import { ArmoryScreen } from './components/ArmoryScreen';
import { SettingsModal } from './components/SettingsModal';
import { AndroidExportModal } from './components/AndroidExportModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { PauseMenu } from './components/PauseMenu';
import { MissionResultModal } from './components/MissionResultModal';
import { Smartphone, Monitor } from 'lucide-react';

// Rank ladder
function calculateRank(xp: number): { rank: number; title: string } {
  if (xp >= 5000) return { rank: 6, title: 'SUPREME GENERAL' };
  if (xp >= 3200) return { rank: 5, title: 'COLONEL' };
  if (xp >= 2000) return { rank: 4, title: 'MAJOR' };
  if (xp >= 1200) return { rank: 3, title: 'CAPTAIN' };
  if (xp >= 600) return { rank: 2, title: 'SERGEANT' };
  if (xp >= 250) return { rank: 1, title: 'SPECIALIST' };
  return { rank: 0, title: 'PRIVATE' };
}

// Storage helpers
const STORAGE_PROG = 'kenecity_progression_v1';
const STORAGE_INV = 'kenecity_inventory_v1';
const STORAGE_SET = 'kenecity_settings_v1';

const defaultProgression: UserProgression = {
  rank: 0,
  rankTitle: 'PRIVATE',
  xp: 0,
  completedMissions: [],
  missionStars: {},
  unlockedWeapons: ['rifle', 'pistol', 'grenade'],
  weaponUpgrades: { rifle: 1, pistol: 1, smg: 1, shotgun: 1, sniper: 1, grenade: 1 },
  totalKills: 0,
  totalHeadshots: 0,
  totalMissionsCompleted: 0,
};

const defaultInventory: PlayerInventory = {
  currentWeaponIndex: 0,
  weapons: ['rifle', 'pistol'],
  ammo: {
    rifle: { currentMag: 30, reserve: 120 },
    pistol: { currentMag: 15, reserve: 60 },
    smg: { currentMag: 32, reserve: 128 },
    shotgun: { currentMag: 8, reserve: 32 },
    sniper: { currentMag: 5, reserve: 20 },
    grenade: { currentMag: 1, reserve: 3 },
  },
  grenadesCount: 3,
};

const defaultSettings: GameSettings = {
  graphicsQuality: 'MEDIUM',
  soundVolume: 0.8,
  musicVolume: 0.5,
  lookSensitivity: 1.0,
  hapticsEnabled: true,
  showMinimap: true,
  invertY: false,
  deviceFramePreview: false,
};

export default function App() {
  // Screens: MENU | MISSIONS | ARMORY | GAMEPLAY
  const [currentScreen, setCurrentScreen] = useState<'MENU' | 'MISSIONS' | 'ARMORY' | 'GAMEPLAY'>('MENU');

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAndroidExportOpen, setIsAndroidExportOpen] = useState(false);
  const [isHowToPlayOpen, setIsHowToPlayOpen] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [missionResult, setMissionResult] = useState<{
    victory: boolean;
    stats: PlayerStats;
    mission: MissionConfig;
  } | null>(null);

  // Persistent user data
  const [progression, setProgression] = useState<UserProgression>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PROG);
      return saved ? JSON.parse(saved) : defaultProgression;
    } catch {
      return defaultProgression;
    }
  });

  const [inventory, setInventory] = useState<PlayerInventory>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_INV);
      return saved ? JSON.parse(saved) : defaultInventory;
    } catch {
      return defaultInventory;
    }
  });

  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_SET);
      return saved ? JSON.parse(saved) : defaultSettings;
    } catch {
      return defaultSettings;
    }
  });

  // Active mission & 3D Engine
  const [activeMission, setActiveMission] = useState<MissionConfig>(CAMPAIGN_MISSIONS[0]);
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Real-time HUD states
  const [liveStats, setLiveStats] = useState<PlayerStats>({
    hp: 100,
    maxHp: 100,
    armor: 100,
    maxArmor: 100,
    score: 0,
    kills: 0,
    headshots: 0,
    shotsFired: 0,
    shotsHit: 0,
    isDead: false,
    isCrouched: false,
    isAiming: false,
    isSprinting: false,
    isReloading: false,
  });

  const [liveInventory, setLiveInventory] = useState<PlayerInventory>(inventory);
  const [hitFeedback, setHitFeedback] = useState(false);
  const [isHeadshotFeedback, setIsHeadshotFeedback] = useState(false);

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_PROG, JSON.stringify(progression));
  }, [progression]);

  useEffect(() => {
    localStorage.setItem(STORAGE_INV, JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_SET, JSON.stringify(settings));
  }, [settings]);

  // Start 3D Engine when entering GAMEPLAY
  useEffect(() => {
    if (currentScreen !== 'GAMEPLAY') {
      if (engineRef.current) {
        engineRef.current.destroy();
        engineRef.current = null;
      }
      return;
    }

    if (!canvasMountRef.current) return;

    // Reset inventory ammunition to full for deployment
    const deployInventory: PlayerInventory = {
      ...inventory,
      ammo: {
        rifle: { currentMag: 30, reserve: 120 },
        pistol: { currentMag: 15, reserve: 60 },
        smg: { currentMag: 32, reserve: 128 },
        shotgun: { currentMag: 8, reserve: 32 },
        sniper: { currentMag: 5, reserve: 20 },
        grenade: { currentMag: 1, reserve: 3 },
      },
      grenadesCount: 3,
    };

    const engine = new GameEngine(
      canvasMountRef.current,
      activeMission,
      settings,
      deployInventory
    );

    engineRef.current = engine;
    setLiveStats(engine.playerStats);
    setLiveInventory(deployInventory);
    setIsPaused(false);
    setMissionResult(null);

    engine.onStatsChanged = (s, inv) => {
      setLiveStats({ ...s });
      setLiveInventory({ ...inv });
    };

    engine.onMissionObjectiveUpdated = (m) => {
      setActiveMission({ ...m });
    };

    engine.onHitFeedback = (isHead) => {
      setHitFeedback(true);
      setIsHeadshotFeedback(isHead);
      setTimeout(() => setHitFeedback(false), 120);
    };

    engine.onMissionCompleted = (victory, finalStats) => {
      // Calculate XP and update progression
      const xpGained = victory ? activeMission.xpReward + finalStats.score : Math.round(finalStats.score * 0.3);
      const newXp = progression.xp + xpGained;
      const rankInfo = calculateRank(newXp);

      let updatedCompleted = [...progression.completedMissions];
      if (victory && !updatedCompleted.includes(activeMission.id)) {
        updatedCompleted.push(activeMission.id);
      }

      // Accuracy & Stars
      const acc = finalStats.shotsFired > 0 ? (finalStats.shotsHit / finalStats.shotsFired) * 100 : 0;
      let stars = 1;
      if (victory) {
        if (finalStats.hp >= 60 || acc >= 40) stars = 2;
        if (finalStats.hp >= 80 && acc >= 50) stars = 3;
      }

      const updatedStars = { ...progression.missionStars };
      if (victory) {
        updatedStars[activeMission.id] = Math.max(updatedStars[activeMission.id] || 0, stars);
      }

      const updatedProg: UserProgression = {
        ...progression,
        xp: newXp,
        rank: rankInfo.rank,
        rankTitle: rankInfo.title,
        completedMissions: updatedCompleted,
        missionStars: updatedStars,
        totalKills: progression.totalKills + finalStats.kills,
        totalHeadshots: progression.totalHeadshots + finalStats.headshots,
        totalMissionsCompleted: progression.totalMissionsCompleted + (victory ? 1 : 0),
      };

      setProgression(updatedProg);
      setMissionResult({
        victory,
        stats: finalStats,
        mission: activeMission,
      });
    };

    const handleResize = () => {
      engine.handleResize();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      engine.destroy();
      engineRef.current = null;
    };
  }, [currentScreen, activeMission.id]);

  // Deployment handlers
  const handleDeployMission = (mission: MissionConfig) => {
    setActiveMission(mission);
    setCurrentScreen('GAMEPLAY');
  };

  const handleRestartMission = () => {
    setIsPaused(false);
    setMissionResult(null);
    if (engineRef.current) {
      engineRef.current.destroy();
      engineRef.current = null;
    }
    // Re-trigger by toggling screen
    setCurrentScreen('MENU');
    setTimeout(() => setCurrentScreen('GAMEPLAY'), 50);
  };

  const handleNextMission = () => {
    const nextMission = CAMPAIGN_MISSIONS.find((m) => m.id === activeMission.id + 1);
    if (nextMission) {
      handleDeployMission(nextMission);
    } else {
      setCurrentScreen('MENU');
    }
  };

  // Smartphone preview container toggle
  const isSmartphoneFrame = settings.deviceFramePreview;

  return (
    <div className="relative w-screen h-screen bg-black overflow-hidden select-none font-sans flex items-center justify-center">
      {/* Frame Preview Wrapper: When Samsung Frame mode is enabled, displays inside a phone frame */}
      <div
        className={`relative transition-all duration-300 overflow-hidden flex items-center justify-center ${
          isSmartphoneFrame
            ? 'w-[92vw] max-w-[920px] h-[55vw] max-h-[460px] rounded-[42px] border-[12px] border-neutral-900 shadow-[0_0_50px_rgba(0,0,0,0.9),0_0_0_3px_#262626] bg-black ring-1 ring-white/10'
            : 'w-full h-full'
        }`}
      >
        {/* Samsung Front Punch-Hole Camera (Visible in phone frame mode) */}
        {isSmartphoneFrame && (
          <div className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-neutral-950 border border-neutral-800 z-50 pointer-events-none flex items-center justify-center shadow-inner">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-900/60" />
          </div>
        )}

        {/* 3D WebGL Canvas Container */}
        <div
          ref={canvasMountRef}
          className={`absolute inset-0 w-full h-full ${
            currentScreen === 'GAMEPLAY' ? 'block' : 'hidden'
          }`}
        />

        {/* GAMEPLAY OVERLAYS */}
        {currentScreen === 'GAMEPLAY' && (
          <>
            <HUD
              stats={liveStats}
              inventory={liveInventory}
              mission={activeMission}
              onPause={() => {
                if (engineRef.current) {
                  engineRef.current.isPaused = true;
                }
                setIsPaused(true);
              }}
              hitFeedback={hitFeedback}
              isHeadshotFeedback={isHeadshotFeedback}
            />

            <TouchControls
              engine={engineRef.current}
              stats={liveStats}
              inventory={liveInventory}
            />
          </>
        )}

        {/* MAIN MENU */}
        {currentScreen === 'MENU' && (
          <MainMenu
            progression={progression}
            onStartCampaign={() => setCurrentScreen('MISSIONS')}
            onOpenArmory={() => setCurrentScreen('ARMORY')}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onOpenAndroidExport={() => setIsAndroidExportOpen(true)}
            onOpenHowToPlay={() => setIsHowToPlayOpen(true)}
          />
        )}

        {/* MISSIONS SCREEN */}
        {currentScreen === 'MISSIONS' && (
          <MissionsScreen
            progression={progression}
            onSelectMission={handleDeployMission}
            onBack={() => setCurrentScreen('MENU')}
          />
        )}

        {/* ARMORY SCREEN */}
        {currentScreen === 'ARMORY' && (
          <ArmoryScreen
            progression={progression}
            inventory={inventory}
            onUpdateInventory={setInventory}
            onUpdateProgression={setProgression}
            onBack={() => setCurrentScreen('MENU')}
          />
        )}

        {/* PAUSE MENU MODAL */}
        {isPaused && (
          <PauseMenu
            onResume={() => {
              if (engineRef.current) {
                engineRef.current.isPaused = false;
              }
              setIsPaused(false);
            }}
            onRestart={handleRestartMission}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onExitToMainMenu={() => {
              setIsPaused(false);
              setCurrentScreen('MENU');
            }}
          />
        )}

        {/* MISSION RESULT (VICTORY / DEFEAT) */}
        {missionResult && (
          <MissionResultModal
            victory={missionResult.victory}
            stats={missionResult.stats}
            mission={missionResult.mission}
            onNextMission={handleNextMission}
            onRetry={handleRestartMission}
            onMainMenu={() => {
              setMissionResult(null);
              setCurrentScreen('MENU');
            }}
          />
        )}
      </div>

      {/* QUICK FLOATING TOGGLE: SAMSUNG LANDSCAPE FRAME PREVIEW */}
      <button
        type="button"
        onClick={() => {
          setSettings((prev) => ({ ...prev, deviceFramePreview: !prev.deviceFramePreview }));
        }}
        title="Toggle Samsung Galaxy Smartphone Landscape Frame Preview"
        className="fixed top-3 right-3 z-50 px-3 py-1.5 rounded-xl bg-black/80 hover:bg-black border border-white/20 text-white text-[11px] font-mono flex items-center gap-1.5 shadow-xl active:scale-95 transition-all cursor-pointer"
      >
        {isSmartphoneFrame ? (
          <>
            <Monitor className="w-3.5 h-3.5 text-cyan-400" />
            <span>FULLSCREEN</span>
          </>
        ) : (
          <>
            <Smartphone className="w-3.5 h-3.5 text-amber-400" />
            <span>SAMSUNG FRAME</span>
          </>
        )}
      </button>

      {/* MODALS */}
      {isSettingsOpen && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={setSettings}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}

      {isAndroidExportOpen && (
        <AndroidExportModal onClose={() => setIsAndroidExportOpen(false)} />
      )}

      {isHowToPlayOpen && (
        <HowToPlayModal onClose={() => setIsHowToPlayOpen(false)} />
      )}
    </div>
  );
}
