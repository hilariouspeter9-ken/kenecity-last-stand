/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type WeaponType = 'rifle' | 'pistol' | 'smg' | 'shotgun' | 'sniper' | 'grenade';

export interface WeaponConfig {
  id: WeaponType;
  name: string;
  category: string;
  damage: number;
  fireRate: number; // shots per second
  magSize: number;
  maxReserveAmmo: number;
  reloadTime: number; // seconds
  range: number;
  spread: number; // radians
  recoil: number;
  zoomFov: number; // FOV in degrees when aiming (normal is 65)
  pelletCount?: number; // for shotgun
  unlockedByDefault: boolean;
  unlockCostXp: number;
  description: string;
}

export interface PlayerInventory {
  currentWeaponIndex: number;
  weapons: WeaponType[];
  ammo: Record<WeaponType, { currentMag: number; reserve: number }>;
  grenadesCount: number;
}

export interface Objective {
  id: string;
  description: string;
  current: number;
  target: number;
  completed: boolean;
  optional?: boolean;
}

export interface MissionConfig {
  id: number;
  title: string;
  codename: string;
  location: string;
  timeOfDay: 'day' | 'sunset' | 'night';
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'EXTREME' | 'NIGHTMARE';
  briefing: string;
  objectives: Objective[];
  xpReward: number;
  enemyCount: number;
  hasBoss?: boolean;
  bossName?: string;
  musicMood: 'tactical' | 'combat' | 'stealth' | 'boss';
}

export interface PlayerStats {
  hp: number;
  maxHp: number;
  armor: number;
  maxArmor: number;
  score: number;
  kills: number;
  headshots: number;
  shotsFired: number;
  shotsHit: number;
  isDead: boolean;
  isCrouched: boolean;
  isAiming: boolean;
  isSprinting: boolean;
  isReloading: boolean;
}

export interface GameSettings {
  graphicsQuality: 'LOW' | 'MEDIUM' | 'HIGH';
  soundVolume: number; // 0 to 1
  musicVolume: number; // 0 to 1
  lookSensitivity: number; // 0.5 to 2.5
  hapticsEnabled: boolean;
  showMinimap: boolean;
  invertY: boolean;
  deviceFramePreview: boolean; // toggle landscape smartphone frame preview
}

export interface UserProgression {
  rank: number;
  rankTitle: string;
  xp: number;
  completedMissions: number[]; // mission IDs completed
  missionStars: Record<number, number>; // mission ID to stars 1-3
  unlockedWeapons: WeaponType[];
  weaponUpgrades: Record<WeaponType, number>; // level 1-3
  totalKills: number;
  totalHeadshots: number;
  totalMissionsCompleted: number;
}
