/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MissionConfig, PlayerStats } from '../types/game';
import { Trophy, Skull, Star, RotateCcw, ArrowRight, Home, Crosshair, Award } from 'lucide-react';
import { soundManager } from '../audio/SoundManager';

interface MissionResultModalProps {
  victory: boolean;
  stats: PlayerStats;
  mission: MissionConfig;
  onNextMission?: () => void;
  onRetry: () => void;
  onMainMenu: () => void;
}

export const MissionResultModal: React.FC<MissionResultModalProps> = ({
  victory,
  stats,
  mission,
  onNextMission,
  onRetry,
  onMainMenu,
}) => {
  const accuracy = stats.shotsFired > 0 ? Math.round((stats.shotsHit / stats.shotsFired) * 100) : 0;

  // Calculate stars
  let stars = 1;
  if (victory) {
    if (stats.hp >= 60 || accuracy >= 40) stars = 2;
    if (stats.hp >= 80 && accuracy >= 50) stars = 3;
  } else {
    stars = 0;
  }

  const xpEarned = victory ? mission.xpReward + stats.score : Math.round(stats.score * 0.3);

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-50 font-sans">
      <div
        className={`border rounded-3xl max-w-md w-full p-6 text-white shadow-2xl flex flex-col items-center relative overflow-hidden ${
          victory ? 'bg-slate-900 border-amber-500/50' : 'bg-stone-950 border-red-600/50'
        }`}
      >
        {/* Banner Glow */}
        <div
          className={`absolute top-0 inset-x-0 h-1.5 ${
            victory ? 'bg-linear-to-r from-amber-400 to-emerald-400' : 'bg-red-600'
          }`}
        />

        {/* Top Icon */}
        <div
          className={`p-4 rounded-full mb-3 ${
            victory
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
              : 'bg-red-600/20 text-red-500 border border-red-500/40'
          }`}
        >
          {victory ? <Trophy className="w-10 h-10" /> : <Skull className="w-10 h-10" />}
        </div>

        {/* Title */}
        <h2 className="text-2xl font-black font-mono tracking-widest text-center mb-0.5">
          {victory ? 'MISSION ACCOMPLISHED' : 'CASUALTY IN ACTION'}
        </h2>
        <p className="text-xs font-mono text-white/60 mb-4">{mission.codename}</p>

        {/* Star Rating for Victory */}
        {victory && (
          <div className="flex items-center gap-2 mb-4">
            {[1, 2, 3].map((s) => (
              <Star
                key={s}
                className={`w-7 h-7 ${
                  s <= stars ? 'text-amber-400 fill-amber-400 drop-shadow-[0_0_8px_#f59e0b]' : 'text-white/20'
                }`}
              />
            ))}
          </div>
        )}

        {/* Stats Grid */}
        <div className="w-full grid grid-cols-2 gap-3 mb-5">
          <div className="bg-black/50 border border-white/10 rounded-xl p-3 flex flex-col items-center">
            <span className="text-[10px] font-mono text-white/50">HOSTILES ELIMINATED</span>
            <div className="flex items-center gap-1.5 mt-1">
              <Crosshair className="w-4 h-4 text-red-400" />
              <span className="text-lg font-mono font-black text-white">{stats.kills}</span>
            </div>
          </div>

          <div className="bg-black/50 border border-white/10 rounded-xl p-3 flex flex-col items-center">
            <span className="text-[10px] font-mono text-white/50">HEADSHOT PRECISION</span>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="text-lg font-mono font-black text-amber-400">{stats.headshots}</span>
            </div>
          </div>

          <div className="bg-black/50 border border-white/10 rounded-xl p-3 flex flex-col items-center">
            <span className="text-[10px] font-mono text-white/50">ACCURACY RATING</span>
            <span className="text-lg font-mono font-black text-cyan-400 mt-1">{accuracy}%</span>
          </div>

          <div className="bg-black/50 border border-white/10 rounded-xl p-3 flex flex-col items-center">
            <span className="text-[10px] font-mono text-white/50">XP REWARD</span>
            <div className="flex items-center gap-1.5 mt-1">
              <Award className="w-4 h-4 text-emerald-400" />
              <span className="text-lg font-mono font-black text-emerald-400">+{xpEarned}</span>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          {victory && onNextMission && mission.id < 5 && (
            <button
              type="button"
              onClick={() => {
                soundManager.playButtonClick();
                onNextMission();
              }}
              className="w-full py-3.5 rounded-xl bg-linear-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-mono font-black text-xs shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <span>PROCEED TO NEXT MISSION</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onRetry();
            }}
            className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-mono font-bold text-xs border border-white/10 flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{victory ? 'REPLAY MISSION' : 'RETRY COMBAT SECTOR'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onMainMenu();
            }}
            className="w-full py-2.5 rounded-xl bg-black/40 hover:bg-black/60 text-white/80 font-mono text-xs border border-white/5 flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Home className="w-4 h-4" />
            <span>RETURN TO BASE</span>
          </button>
        </div>
      </div>
    </div>
  );
};
