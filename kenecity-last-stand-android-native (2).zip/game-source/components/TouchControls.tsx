/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { GameEngine } from '../game/GameEngine';
import { PlayerInventory, PlayerStats } from '../types/game';
import {
  Crosshair,
  Flame,
  RotateCcw,
  Zap,
  Bomb,
  ArrowBigUp,
  Shield,
  ChevronsRight,
} from 'lucide-react';

interface TouchControlsProps {
  engine: GameEngine | null;
  stats: PlayerStats;
  inventory: PlayerInventory;
}

export const TouchControls: React.FC<TouchControlsProps> = ({ engine, stats, inventory }) => {
  // Joystick State (Left side)
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });
  const [isJoystickActive, setIsJoystickActive] = useState(false);
  const joystickTouchIdRef = useRef<number | null>(null);
  const joystickStartPosRef = useRef({ x: 0, y: 0 });

  // Camera Drag State (Right side)
  const lookTouchPadRef = useRef<HTMLDivElement>(null);
  const lookTouchIdRef = useRef<number | null>(null);
  const lookLastPosRef = useRef({ x: 0, y: 0 });

  // Fire Button hold state
  const isFiringRef = useRef(false);

  // --- JOYSTICK TOUCH HANDLERS ---
  const handleJoystickTouchStart = (e: React.TouchEvent) => {
    if (joystickTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    joystickTouchIdRef.current = touch.identifier;

    const rect = joystickBaseRef.current?.getBoundingClientRect();
    if (rect) {
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      joystickStartPosRef.current = { x: centerX, y: centerY };
    }
    setIsJoystickActive(true);
  };

  const handleJoystickTouchMove = (e: React.TouchEvent) => {
    if (joystickTouchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === joystickTouchIdRef.current) {
        const dx = touch.clientX - joystickStartPosRef.current.x;
        const dy = touch.clientY - joystickStartPosRef.current.y;
        const distance = Math.hypot(dx, dy);
        const maxRadius = 45;

        let clampedX = dx;
        let clampedY = dy;
        if (distance > maxRadius) {
          clampedX = (dx / distance) * maxRadius;
          clampedY = (dy / distance) * maxRadius;
        }

        setJoystickPos({ x: clampedX, y: clampedY });

        // Normalize to -1 to 1 for GameEngine (y inverted for forward)
        const normX = clampedX / maxRadius;
        const normY = -clampedY / maxRadius;
        engine?.setMoveVector(normX, normY);
        break;
      }
    }
  };

  const handleJoystickTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joystickTouchIdRef.current) {
        joystickTouchIdRef.current = null;
        setJoystickPos({ x: 0, y: 0 });
        setIsJoystickActive(false);
        engine?.setMoveVector(0, 0);
        break;
      }
    }
  };

  // --- CAMERA LOOK TOUCH HANDLERS ---
  const handleLookTouchStart = (e: React.TouchEvent) => {
    if (lookTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    lookTouchIdRef.current = touch.identifier;
    lookLastPosRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleLookTouchMove = (e: React.TouchEvent) => {
    if (lookTouchIdRef.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === lookTouchIdRef.current) {
        const dx = touch.clientX - lookLastPosRef.current.x;
        const dy = touch.clientY - lookLastPosRef.current.y;
        lookLastPosRef.current = { x: touch.clientX, y: touch.clientY };

        engine?.applyLookDelta(dx, dy);
        break;
      }
    }
  };

  const handleLookTouchEnd = (e: React.TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === lookTouchIdRef.current) {
        lookTouchIdRef.current = null;
        break;
      }
    }
  };

  // --- KEYBOARD & MOUSE DESKTOP FALLBACK ---
  useEffect(() => {
    const keysPressed = new Set<string>();

    const updateKeyboardMove = () => {
      let x = 0;
      let y = 0;
      if (keysPressed.has('KeyW') || keysPressed.has('ArrowUp')) y += 1;
      if (keysPressed.has('KeyS') || keysPressed.has('ArrowDown')) y -= 1;
      if (keysPressed.has('KeyA') || keysPressed.has('ArrowLeft')) x -= 1;
      if (keysPressed.has('KeyD') || keysPressed.has('ArrowRight')) x += 1;
      engine?.setMoveVector(x, y);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        keysPressed.add(e.code);
        updateKeyboardMove();
      }
      if (e.code === 'Space') {
        engine?.jump();
      }
      if (e.code === 'KeyC') {
        engine?.toggleCrouch();
      }
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        engine?.setSprinting(true);
      }
      if (e.code === 'KeyR') {
        engine?.reload();
      }
      if (e.code === 'KeyG') {
        engine?.throwGrenade();
      }
      if (e.code === 'KeyQ') {
        engine?.prevWeapon();
      }
      if (e.code === 'KeyE') {
        engine?.nextWeapon();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        keysPressed.delete(e.code);
        updateKeyboardMove();
      }
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        engine?.setSprinting(false);
      }
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) {
        // Left click shoot
        engine?.startFiring();
      } else if (e.button === 2) {
        // Right click aim
        engine?.toggleAim();
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        engine?.stopFiring();
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement) {
        engine?.applyLookDelta(e.movementX, e.movementY);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [engine]);

  return (
    <div className="absolute inset-0 pointer-events-none z-10 select-none overflow-hidden touch-none font-sans">
      {/* LEFT ZONE: Virtual Joystick & Stance Controls */}
      <div className="absolute left-4 bottom-6 flex items-end gap-3 pointer-events-auto">
        {/* Virtual Joystick Container */}
        <div
          ref={joystickBaseRef}
          onTouchStart={handleJoystickTouchStart}
          onTouchMove={handleJoystickTouchMove}
          onTouchEnd={handleJoystickTouchEnd}
          onTouchCancel={handleJoystickTouchEnd}
          className="relative w-28 h-28 rounded-full border-2 border-emerald-500/40 bg-black/40 backdrop-blur-xs flex items-center justify-center shadow-lg"
          style={{ touchAction: 'none' }}
        >
          {/* Outer direction markers */}
          <div className="absolute top-1 text-[9px] font-mono tracking-widest text-emerald-400/60 font-bold">▲</div>
          <div className="absolute bottom-1 text-[9px] font-mono tracking-widest text-emerald-400/60 font-bold">▼</div>
          <div className="absolute left-1 text-[9px] font-mono tracking-widest text-emerald-400/60 font-bold">◄</div>
          <div className="absolute right-1 text-[9px] font-mono tracking-widest text-emerald-400/60 font-bold">►</div>

          {/* Stick thumb */}
          <div
            className={`w-12 h-12 rounded-full shadow-md transition-transform duration-75 flex items-center justify-center ${
              isJoystickActive ? 'bg-emerald-500 shadow-emerald-500/50 scale-105' : 'bg-emerald-600/80'
            }`}
            style={{
              transform: `translate(${joystickPos.x}px, ${joystickPos.y}px)`,
            }}
          >
            <div className="w-4 h-4 rounded-full bg-white/70" />
          </div>
        </div>

        {/* Sprint & Crouch buttons next to stick */}
        <div className="flex flex-col gap-2">
          <button
            type="button"
            onClick={() => engine?.setSprinting(!stats.isSprinting)}
            className={`w-11 h-11 rounded-xl flex flex-col items-center justify-center border text-xs font-mono font-bold transition-all active:scale-95 shadow-md ${
              stats.isSprinting
                ? 'bg-amber-500 border-amber-300 text-black shadow-amber-500/40'
                : 'bg-black/50 border-white/20 text-white/80'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span className="text-[8px] leading-none">SPRINT</span>
          </button>

          <button
            type="button"
            onClick={() => engine?.toggleCrouch()}
            className={`w-11 h-11 rounded-xl flex flex-col items-center justify-center border text-xs font-mono font-bold transition-all active:scale-95 shadow-md ${
              stats.isCrouched
                ? 'bg-emerald-500 border-emerald-300 text-black shadow-emerald-500/40'
                : 'bg-black/50 border-white/20 text-white/80'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span className="text-[8px] leading-none">CROUCH</span>
          </button>
        </div>
      </div>

      {/* RIGHT ZONE: Camera Look Swipe Area (Covers right 60% of viewport, pointer-events-auto) */}
      <div
        ref={lookTouchPadRef}
        onTouchStart={handleLookTouchStart}
        onTouchMove={handleLookTouchMove}
        onTouchEnd={handleLookTouchEnd}
        onTouchCancel={handleLookTouchEnd}
        className="absolute right-0 top-0 bottom-0 w-3/5 pointer-events-auto"
        style={{ touchAction: 'none' }}
      />

      {/* RIGHT ACTION BUTTONS (Elevated above look zone) */}
      <div className="absolute right-4 bottom-5 flex flex-col items-end gap-3 pointer-events-auto">
        {/* Upper Row: Grenade & Weapon Switch Carousel */}
        <div className="flex items-center gap-2 mb-1">
          <button
            type="button"
            onClick={() => engine?.throwGrenade()}
            disabled={inventory.grenadesCount <= 0}
            className="w-12 h-12 rounded-full bg-red-950/80 border border-red-500/60 text-red-300 flex flex-col items-center justify-center shadow-lg active:scale-90 transition-transform"
          >
            <Bomb className="w-5 h-5 text-red-400" />
            <span className="text-[9px] font-mono font-black">{inventory.grenadesCount}</span>
          </button>

          <button
            type="button"
            onClick={() => engine?.nextWeapon()}
            className="px-3 h-10 rounded-xl bg-slate-900/90 border border-slate-600/80 text-white flex items-center gap-1.5 shadow-lg active:scale-95 text-xs font-mono font-semibold"
          >
            <ChevronsRight className="w-4 h-4 text-emerald-400" />
            <span>SWAP GUN</span>
          </button>
        </div>

        {/* Lower Row: Aim, Reload, Jump & Primary Fire Trigger */}
        <div className="relative flex items-end gap-3">
          {/* Aim Down Sights (ADS) */}
          <button
            type="button"
            onClick={() => engine?.toggleAim()}
            className={`w-13 h-13 rounded-full flex flex-col items-center justify-center border font-mono font-bold shadow-xl active:scale-95 transition-all ${
              stats.isAiming
                ? 'bg-amber-500 border-amber-300 text-black shadow-amber-500/50'
                : 'bg-slate-900/80 border-white/30 text-white'
            }`}
          >
            <Crosshair className="w-6 h-6" />
            <span className="text-[8px]">AIM</span>
          </button>

          {/* Reload Button */}
          <button
            type="button"
            onClick={() => engine?.reload()}
            disabled={stats.isReloading}
            className={`w-12 h-12 rounded-full bg-slate-900/80 border border-white/30 text-white flex flex-col items-center justify-center shadow-xl active:scale-95 transition-all ${
              stats.isReloading ? 'animate-spin border-amber-400 text-amber-400' : ''
            }`}
          >
            <RotateCcw className="w-5 h-5" />
            <span className="text-[8px] font-mono">RELOAD</span>
          </button>

          {/* Jump Button */}
          <button
            type="button"
            onClick={() => engine?.jump()}
            className="w-12 h-12 rounded-full bg-slate-900/80 border border-white/30 text-white flex flex-col items-center justify-center shadow-xl active:scale-95"
          >
            <ArrowBigUp className="w-6 h-6" />
            <span className="text-[8px] font-mono">JUMP</span>
          </button>

          {/* Huge Main Fire Button */}
          <button
            type="button"
            onPointerDown={() => {
              isFiringRef.current = true;
              engine?.startFiring();
            }}
            onPointerUp={() => {
              isFiringRef.current = false;
              engine?.stopFiring();
            }}
            onPointerLeave={() => {
              if (isFiringRef.current) {
                isFiringRef.current = false;
                engine?.stopFiring();
              }
            }}
            className="w-20 h-20 rounded-full bg-linear-to-tr from-red-600 to-amber-500 border-2 border-amber-300 text-white flex flex-col items-center justify-center shadow-2xl active:scale-90 transition-transform cursor-pointer"
          >
            <Flame className="w-8 h-8 text-amber-100 drop-shadow-md" />
            <span className="text-[10px] font-mono font-black tracking-wider text-amber-100">FIRE</span>
          </button>
        </div>
      </div>
    </div>
  );
};
