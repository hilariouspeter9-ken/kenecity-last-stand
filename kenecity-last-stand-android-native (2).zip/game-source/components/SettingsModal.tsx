/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { GameSettings } from '../types/game';
import { X, Volume2, Music, Sparkles, Smartphone, Eye } from 'lucide-react';
import { soundManager } from '../audio/SoundManager';

interface SettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (settings: GameSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  const updateSetting = <K extends keyof GameSettings>(key: K, value: GameSettings[K]) => {
    soundManager.playButtonClick();
    const updated = { ...settings, [key]: value };
    onUpdateSettings(updated);

    if (key === 'soundVolume' || key === 'musicVolume') {
      soundManager.setVolumes(updated.soundVolume, updated.musicVolume);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 font-sans">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white active:scale-95 transition-transform"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-black font-mono text-amber-400 tracking-wider mb-5 flex items-center gap-2">
          <span>SYSTEM & GRAPHICS SETTINGS</span>
        </h2>

        <div className="space-y-5 text-sm">
          {/* Graphics Quality */}
          <div>
            <div className="flex items-center gap-2 text-white/80 font-mono text-xs uppercase mb-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>3D Graphics Preset:</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(['LOW', 'MEDIUM', 'HIGH'] as const).map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => updateSetting('graphicsQuality', q)}
                  className={`py-2 px-3 rounded-xl font-mono text-xs font-bold border transition-all ${
                    settings.graphicsQuality === q
                      ? 'bg-amber-500 border-amber-300 text-black shadow-lg'
                      : 'bg-black/40 border-white/10 text-white/70 hover:bg-black/60'
                  }`}
                >
                  {q === 'LOW' ? 'LOW (4GB RAM)' : q === 'MEDIUM' ? 'BALANCED' : 'HIGH (MAX)'}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-white/50 mt-1 font-mono">
              {settings.graphicsQuality === 'LOW'
                ? 'Optimized for low-RAM smartphones: disabled shadows, 1.0x pixel ratio.'
                : settings.graphicsQuality === 'MEDIUM'
                ? 'Standard 60fps preset: soft shadows, 1024 depth map.'
                : 'Maximum fidelity: PCF soft shadow filter, high-res lighting & reflections.'}
            </p>
          </div>

          {/* Sound FX Volume */}
          <div>
            <div className="flex justify-between items-center text-xs font-mono mb-1.5 text-white/80">
              <span className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <span>Sound FX Volume:</span>
              </span>
              <span className="font-bold text-amber-400">{Math.round(settings.soundVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.soundVolume}
              onChange={(e) => updateSetting('soundVolume', parseFloat(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          {/* Music Volume */}
          <div>
            <div className="flex justify-between items-center text-xs font-mono mb-1.5 text-white/80">
              <span className="flex items-center gap-2">
                <Music className="w-4 h-4 text-cyan-400" />
                <span>Music Volume:</span>
              </span>
              <span className="font-bold text-amber-400">{Math.round(settings.musicVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.musicVolume}
              onChange={(e) => updateSetting('musicVolume', parseFloat(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          {/* Look Sensitivity */}
          <div>
            <div className="flex justify-between items-center text-xs font-mono mb-1.5 text-white/80">
              <span className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-purple-400" />
                <span>Touch Camera Sensitivity:</span>
              </span>
              <span className="font-bold text-amber-400">{settings.lookSensitivity.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.5"
              step="0.1"
              value={settings.lookSensitivity}
              onChange={(e) => updateSetting('lookSensitivity', parseFloat(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          {/* Toggles */}
          <div className="space-y-3 pt-2 border-t border-white/10">
            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-xs font-mono text-white/80">Haptic Vibration on Firing / Hits:</span>
              <input
                type="checkbox"
                checked={settings.hapticsEnabled}
                onChange={(e) => updateSetting('hapticsEnabled', e.target.checked)}
                className="w-4 h-4 accent-amber-400"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-xs font-mono text-white/80">Invert Camera Y-Axis:</span>
              <input
                type="checkbox"
                checked={settings.invertY}
                onChange={(e) => updateSetting('invertY', e.target.checked)}
                className="w-4 h-4 accent-amber-400"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-xs font-mono text-white/80 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>Samsung Phone Landscape Frame:</span>
              </span>
              <input
                type="checkbox"
                checked={settings.deviceFramePreview}
                onChange={(e) => updateSetting('deviceFramePreview', e.target.checked)}
                className="w-4 h-4 accent-amber-400"
              />
            </label>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-white/10 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-mono font-bold text-xs shadow-lg active:scale-95 transition-all"
          >
            CONFIRM & CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
