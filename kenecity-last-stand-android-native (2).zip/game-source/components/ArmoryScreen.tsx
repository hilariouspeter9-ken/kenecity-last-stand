/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { WEAPON_CONFIGS } from '../game/weapons';
import { PlayerInventory, UserProgression, WeaponType } from '../types/game';
import { ArrowLeft, Check, Lock, Shield, Zap, Crosshair } from 'lucide-react';
import { soundManager } from '../audio/SoundManager';

interface ArmoryScreenProps {
  progression: UserProgression;
  inventory: PlayerInventory;
  onUpdateInventory: (inv: PlayerInventory) => void;
  onUpdateProgression: (prog: UserProgression) => void;
  onBack: () => void;
}

export const ArmoryScreen: React.FC<ArmoryScreenProps> = ({
  progression,
  inventory,
  onUpdateInventory,
  onUpdateProgression,
  onBack,
}) => {
  const [selectedWeaponId, setSelectedWeaponId] = useState<WeaponType>(
    inventory.weapons[inventory.currentWeaponIndex] || 'rifle'
  );

  const selectedConfig = WEAPON_CONFIGS[selectedWeaponId];
  const isUnlocked = progression.unlockedWeapons.includes(selectedWeaponId);
  const isEquipped = inventory.weapons.includes(selectedWeaponId);

  const handleUnlock = (weaponId: WeaponType) => {
    const config = WEAPON_CONFIGS[weaponId];
    if (progression.xp < config.unlockCostXp) return;

    soundManager.playButtonClick();
    const updatedProg: UserProgression = {
      ...progression,
      xp: progression.xp - config.unlockCostXp,
      unlockedWeapons: [...progression.unlockedWeapons, weaponId],
    };
    onUpdateProgression(updatedProg);
  };

  const handleEquip = (weaponId: WeaponType) => {
    soundManager.playButtonClick();
    let updatedWeapons = [...inventory.weapons];
    if (!updatedWeapons.includes(weaponId)) {
      // Add or replace
      updatedWeapons.push(weaponId);
    }
    const newIdx = updatedWeapons.indexOf(weaponId);
    const updatedInv: PlayerInventory = {
      ...inventory,
      weapons: updatedWeapons,
      currentWeaponIndex: newIdx,
    };
    onUpdateInventory(updatedInv);
  };

  return (
    <div className="absolute inset-0 bg-slate-950/95 text-white flex flex-col p-6 z-30 overflow-y-auto font-sans">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6 max-w-5xl mx-auto w-full">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-sm font-mono active:scale-95 transition-transform"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>BACK TO BASE</span>
        </button>

        <div className="text-center">
          <h1 className="text-2xl font-black tracking-widest text-amber-400 font-mono">
            WEAPONS ARMORY
          </h1>
          <p className="text-xs text-white/60">EQUIP & UNLOCK MILITARY ARSENAL</p>
        </div>

        <div className="bg-black/60 border border-amber-500/30 rounded-lg px-3 py-1 text-xs font-mono text-amber-400">
          XP BALANCE: {progression.xp}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto w-full pb-8 flex-1">
        {/* Left Column: Weapon List Carousel */}
        <div className="flex flex-col gap-2.5">
          {(Object.keys(WEAPON_CONFIGS) as WeaponType[]).map((wId) => {
            const w = WEAPON_CONFIGS[wId];
            const unlocked = progression.unlockedWeapons.includes(wId);
            const isCurrent = selectedWeaponId === wId;
            const equipped = inventory.weapons.includes(wId);

            return (
              <button
                key={wId}
                type="button"
                onClick={() => {
                  setSelectedWeaponId(wId);
                  soundManager.playButtonClick();
                }}
                className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                  isCurrent
                    ? 'bg-amber-500/20 border-amber-400 shadow-lg'
                    : 'bg-slate-900/80 border-slate-700/80 hover:bg-slate-800'
                }`}
              >
                <div>
                  <div className="text-[10px] font-mono text-emerald-400 uppercase">{w.category}</div>
                  <div className="text-sm font-black text-white">{w.name}</div>
                </div>

                <div className="flex items-center gap-1.5">
                  {equipped && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/30 text-emerald-300 border border-emerald-500/40">
                      EQUIPPED
                    </span>
                  )}
                  {!unlocked && <Lock className="w-4 h-4 text-white/40" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Columns: Weapon Detail & Stats Inspector */}
        <div className="md:col-span-2 bg-slate-900/90 border border-slate-700 rounded-2xl p-6 flex flex-col justify-between shadow-2xl">
          <div>
            <div className="flex items-start justify-between mb-4">
              <div>
                <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest">
                  {selectedConfig.category}
                </span>
                <h2 className="text-2xl font-black text-white mb-1">{selectedConfig.name}</h2>
                <p className="text-xs text-white/70 max-w-lg leading-relaxed">{selectedConfig.description}</p>
              </div>

              {isEquipped ? (
                <div className="flex items-center gap-1 text-emerald-400 font-mono text-xs px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40">
                  <Check className="w-4 h-4" />
                  <span>ACTIVE IN LOADOUT</span>
                </div>
              ) : isUnlocked ? (
                <button
                  type="button"
                  onClick={() => handleEquip(selectedWeaponId)}
                  className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-mono font-black text-xs shadow-lg active:scale-95 transition-all"
                >
                  EQUIP TO LOADOUT
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => handleUnlock(selectedWeaponId)}
                  disabled={progression.xp < selectedConfig.unlockCostXp}
                  className={`px-5 py-2 rounded-xl font-mono font-black text-xs shadow-lg active:scale-95 transition-all ${
                    progression.xp >= selectedConfig.unlockCostXp
                      ? 'bg-amber-400 hover:bg-amber-300 text-black'
                      : 'bg-white/10 text-white/40 cursor-not-allowed'
                  }`}
                >
                  UNLOCK ({selectedConfig.unlockCostXp} XP)
                </button>
              )}
            </div>

            {/* Tactical Stat Bars */}
            <div className="grid grid-cols-2 gap-4 mt-6">
              {/* Damage */}
              <div className="bg-black/40 rounded-xl p-3 border border-white/5">
                <div className="flex justify-between text-xs font-mono mb-1.5">
                  <span className="text-white/60">FIREPOWER / DAMAGE</span>
                  <span className="text-amber-400 font-bold">{selectedConfig.damage}</span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-amber-500"
                    style={{ width: `${Math.min(100, (selectedConfig.damage / 130) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Fire Rate */}
              <div className="bg-black/40 rounded-xl p-3 border border-white/5">
                <div className="flex justify-between text-xs font-mono mb-1.5">
                  <span className="text-white/60">FIRE RATE (ROUNDS/SEC)</span>
                  <span className="text-cyan-400 font-bold">{selectedConfig.fireRate}</span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-cyan-400"
                    style={{ width: `${Math.min(100, (selectedConfig.fireRate / 16) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Range */}
              <div className="bg-black/40 rounded-xl p-3 border border-white/5">
                <div className="flex justify-between text-xs font-mono mb-1.5">
                  <span className="text-white/60">EFFECTIVE COMBAT RANGE</span>
                  <span className="text-emerald-400 font-bold">{selectedConfig.range}m</span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-emerald-400"
                    style={{ width: `${Math.min(100, (selectedConfig.range / 220) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Mag Capacity */}
              <div className="bg-black/40 rounded-xl p-3 border border-white/5">
                <div className="flex justify-between text-xs font-mono mb-1.5">
                  <span className="text-white/60">MAGAZINE CAPACITY</span>
                  <span className="text-purple-400 font-bold">{selectedConfig.magSize} ROUNDS</span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-purple-400"
                    style={{ width: `${Math.min(100, (selectedConfig.magSize / 35) * 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-white/50 font-mono">
            <span>TACTICAL RECOIL FACTOR: {selectedConfig.recoil}</span>
            <span>RELOAD DURATION: {selectedConfig.reloadTime}s</span>
          </div>
        </div>
      </div>
    </div>
  );
};
