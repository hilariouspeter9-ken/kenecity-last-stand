/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CAMPAIGN_MISSIONS } from '../game/missions';
import { MissionConfig, UserProgression } from '../types/game';
import { ArrowLeft, Play, Star, ShieldAlert, Clock, MapPin } from 'lucide-react';

interface MissionsScreenProps {
  progression: UserProgression;
  onSelectMission: (mission: MissionConfig) => void;
  onBack: () => void;
}

export const MissionsScreen: React.FC<MissionsScreenProps> = ({
  progression,
  onSelectMission,
  onBack,
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/95 text-white flex flex-col p-6 z-30 overflow-y-auto font-sans">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6 max-w-5xl mx-auto w-full">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-sm font-mono active:scale-95 transition-transform"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>BACK TO BASE</span>
        </button>

        <div className="text-center">
          <h1 className="text-2xl font-black tracking-widest text-amber-400 font-mono">
            CAMPAIGN THEATER
          </h1>
          <p className="text-xs text-white/60">SELECT COMBAT SECTOR TO DEPLOY</p>
        </div>

        <div className="bg-black/60 border border-white/10 rounded-lg px-3 py-1 text-xs font-mono text-emerald-400">
          RANK: {progression.rankTitle}
        </div>
      </div>

      {/* Mission Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl mx-auto w-full pb-8">
        {CAMPAIGN_MISSIONS.map((mission) => {
          const isUnlocked = mission.id === 1 || progression.completedMissions.includes(mission.id - 1);
          const isCompleted = progression.completedMissions.includes(mission.id);
          const stars = progression.missionStars[mission.id] || 0;

          return (
            <div
              key={mission.id}
              className={`flex flex-col justify-between rounded-2xl p-5 border transition-all ${
                isUnlocked
                  ? 'bg-slate-900/90 border-slate-700/80 hover:border-amber-400/80 shadow-xl'
                  : 'bg-black/40 border-white/5 opacity-50 grayscale'
              }`}
            >
              <div>
                {/* Top Badge */}
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    MISSION 0{mission.id}
                  </span>
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3].map((s) => (
                      <Star
                        key={s}
                        className={`w-3.5 h-3.5 ${
                          s <= stars ? 'text-amber-400 fill-amber-400' : 'text-white/20'
                        }`}
                      />
                    ))}
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-lg font-black tracking-wide text-white mb-0.5">{mission.title}</h3>
                <p className="text-xs font-mono text-emerald-400 mb-3">{mission.codename}</p>

                {/* Location & Time */}
                <div className="flex items-center gap-3 text-[11px] text-white/60 mb-3">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-red-400" />
                    <span className="truncate max-w-[120px]">{mission.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-amber-400" />
                    <span className="capitalize">{mission.timeOfDay}</span>
                  </div>
                </div>

                {/* Briefing Text */}
                <p className="text-xs text-white/70 line-clamp-3 mb-4 leading-relaxed">
                  {mission.briefing}
                </p>

                {/* Primary Objective Preview */}
                <div className="bg-black/40 rounded-lg p-2.5 border border-white/5 mb-4">
                  <div className="text-[10px] font-mono text-white/50 mb-1">PRIMARY OBJECTIVE:</div>
                  <div className="text-xs text-white/90 font-medium">
                    {mission.objectives[0].description}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2 border-t border-white/10 flex items-center justify-between">
                <div className="text-xs font-mono text-amber-400">+{mission.xpReward} XP</div>

                {isUnlocked ? (
                  <button
                    type="button"
                    onClick={() => onSelectMission(mission)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-linear-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-mono font-bold text-xs shadow-lg active:scale-95 transition-all"
                  >
                    <Play className="w-3.5 h-3.5 fill-black" />
                    <span>{isCompleted ? 'REPLAY' : 'DEPLOY'}</span>
                  </button>
                ) : (
                  <div className="flex items-center gap-1 text-xs font-mono text-red-400/80">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>LOCKED</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
