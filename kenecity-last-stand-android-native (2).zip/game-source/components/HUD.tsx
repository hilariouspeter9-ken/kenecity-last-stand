/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { MissionConfig, PlayerInventory, PlayerStats } from '../types/game';
import { WEAPON_CONFIGS } from '../game/weapons';
import { Shield, Heart, Pause, Target, Crosshair, AlertCircle, Award } from 'lucide-react';

interface HUDProps {
  stats: PlayerStats;
  inventory: PlayerInventory;
  mission: MissionConfig;
  onPause: () => void;
  hitFeedback: boolean;
  isHeadshotFeedback: boolean;
}

export const HUD: React.FC<HUDProps> = ({
  stats,
  inventory,
  mission,
  onPause,
  hitFeedback,
  isHeadshotFeedback,
}) => {
  const currentWeapon = inventory.weapons[inventory.currentWeaponIndex];
  const config = WEAPON_CONFIGS[currentWeapon];
  const ammoData = inventory.ammo[currentWeapon];

  // Damage vignette state
  const isHurt = stats.hp < 35;

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-20 flex flex-col justify-between p-3 font-sans overflow-hidden">
      {/* Red Hurt Vignette when health is low or hit */}
      {isHurt && (
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(180,0,0,0.55)_100%)] animate-pulse" />
      )}

      {/* TOP HEADER: Player Vitals & Mission Objective Banner */}
      <div className="flex items-start justify-between w-full">
        {/* Left: Health & Armor Vitals */}
        <div className="flex flex-col gap-1.5 bg-black/60 backdrop-blur-xs border border-white/10 rounded-xl p-2.5 shadow-lg min-w-44">
          {/* Health Bar */}
          <div className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-red-500 fill-red-500 shrink-0" />
            <div className="flex-1 bg-red-950/60 h-3 rounded-full overflow-hidden border border-red-500/30">
              <div
                className="h-full bg-linear-to-r from-red-600 to-rose-400 transition-all duration-200"
                style={{ width: `${Math.max(0, (stats.hp / stats.maxHp) * 100)}%` }}
              />
            </div>
            <span className="text-xs font-mono font-bold text-red-200 w-7 text-right">
              {Math.ceil(stats.hp)}
            </span>
          </div>

          {/* Armor Bar */}
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-cyan-400 fill-cyan-400/30 shrink-0" />
            <div className="flex-1 bg-cyan-950/60 h-2.5 rounded-full overflow-hidden border border-cyan-500/30">
              <div
                className="h-full bg-linear-to-r from-cyan-600 to-teal-300 transition-all duration-200"
                style={{ width: `${Math.max(0, (stats.armor / stats.maxArmor) * 100)}%` }}
              />
            </div>
            <span className="text-xs font-mono font-bold text-cyan-200 w-7 text-right">
              {Math.ceil(stats.armor)}
            </span>
          </div>
        </div>

        {/* Center: Mission Objective HUD Card */}
        <div className="bg-black/70 backdrop-blur-xs border border-amber-500/40 rounded-xl px-4 py-2 max-w-md shadow-xl flex flex-col items-center">
          <div className="flex items-center gap-1.5 text-[11px] font-mono font-bold text-amber-400 tracking-wider uppercase mb-0.5">
            <Target className="w-3.5 h-3.5" />
            <span>{mission.codename}</span>
          </div>
          <div className="flex flex-col gap-0.5 text-center">
            {mission.objectives.map((obj) => (
              <div
                key={obj.id}
                className={`text-xs font-medium flex items-center gap-1.5 ${
                  obj.completed ? 'text-emerald-400 line-through' : 'text-white'
                }`}
              >
                <span>{obj.completed ? '✓' : '•'}</span>
                <span>{obj.description}</span>
                <span className="font-mono text-[11px] text-amber-300">
                  ({obj.current}/{obj.target})
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Score, Kills & Pause Button */}
        <div className="flex items-center gap-2">
          <div className="bg-black/60 backdrop-blur-xs border border-white/10 rounded-xl px-3 py-1.5 flex items-center gap-3 text-xs font-mono text-white/90 shadow-lg">
            <div className="flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-bold">{stats.score}</span>
            </div>
            <div className="flex items-center gap-1 text-red-400">
              <Crosshair className="w-3.5 h-3.5" />
              <span className="font-bold">{stats.kills}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onPause}
            className="w-10 h-10 rounded-xl bg-black/70 hover:bg-black border border-white/20 text-white flex items-center justify-center pointer-events-auto active:scale-95 shadow-lg"
          >
            <Pause className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* CENTER: Crosshair Reticle & Hitmarker */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {/* Full Sniper Scope Reticle when aiming with Sniper */}
        {stats.isAiming && currentWeapon === 'sniper' ? (
          <div className="relative w-72 h-72 rounded-full border border-black/80 shadow-[0_0_0_9999px_rgba(0,0,0,0.85)] flex items-center justify-center">
            {/* Sniper Crosshairs */}
            <div className="absolute w-full h-[1px] bg-red-500/80" />
            <div className="absolute h-full w-[1px] bg-red-500/80" />
            <div className="w-3 h-3 rounded-full border border-red-500" />
            <div className="absolute top-4 text-[10px] font-mono text-red-400">AWM .338 SCOPE</div>
          </div>
        ) : (
          /* Dynamic Tactical Reticle */
          <div
            className={`relative flex items-center justify-center transition-all duration-150 ${
              stats.isAiming ? 'scale-75' : stats.isCrouched ? 'scale-90' : 'scale-100'
            }`}
          >
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400/90 shadow-[0_0_6px_#10b981]" />
            <div className="absolute -top-3 w-0.5 h-2 bg-white/70" />
            <div className="absolute -bottom-3 w-0.5 h-2 bg-white/70" />
            <div className="absolute -left-3 h-0.5 w-2 bg-white/70" />
            <div className="absolute -right-3 h-0.5 w-2 bg-white/70" />
          </div>
        )}

        {/* Hitmarker Flash */}
        {hitFeedback && (
          <div className="absolute w-8 h-8 flex items-center justify-center pointer-events-none animate-ping">
            <span className={`text-xl font-black ${isHeadshotFeedback ? 'text-red-500' : 'text-amber-400'}`}>
              ✕
            </span>
          </div>
        )}
      </div>

      {/* BOTTOM RIGHT: Weapon Armory Badge */}
      <div className="flex justify-end pr-28 pb-4">
        <div className="bg-black/75 backdrop-blur-xs border border-white/20 rounded-2xl px-4 py-2 flex items-center gap-4 shadow-xl">
          <div className="flex flex-col">
            <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold">
              {config.category}
            </span>
            <span className="text-sm font-black text-white">{config.name}</span>
          </div>

          <div className="flex items-baseline gap-1 font-mono">
            <span
              className={`text-2xl font-black ${
                ammoData.currentMag <= 5 ? 'text-red-500 animate-bounce' : 'text-white'
              }`}
            >
              {ammoData.currentMag}
            </span>
            <span className="text-sm text-white/50">/ {ammoData.reserve}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
