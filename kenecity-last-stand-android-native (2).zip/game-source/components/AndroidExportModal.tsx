/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Download,
  CheckCircle,
  Smartphone,
  Terminal,
  FileCode,
  X,
  Copy,
  Check,
  FolderArchive,
  Layers,
} from 'lucide-react';
import { soundManager } from '../audio/SoundManager';

interface AndroidExportModalProps {
  onClose: () => void;
}

export const AndroidExportModal: React.FC<AndroidExportModalProps> = ({ onClose }) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    soundManager.playButtonClick();

    try {
      // Trigger download from backend API which packages all real compiled assets in app/src/main/assets/
      const res = await fetch('/api/download-android-zip');
      if (!res.ok) {
        throw new Error(`Download failed with status ${res.status}`);
      }

      const blob = await res.blob();
      const downloadUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = 'kenecity-last-stand-android-native.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);

      setDownloadSuccess(true);
      soundManager.playVictory();
    } catch (err) {
      console.error('Download error, falling back to direct navigation:', err);
      window.location.href = '/api/download-android-zip';
      setDownloadSuccess(true);
    } finally {
      setIsDownloading(false);
    }
  };

  const copyBuildCommand = () => {
    navigator.clipboard.writeText('./gradlew assembleDebug');
    setCopiedCmd(true);
    soundManager.playButtonClick();
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-50 font-sans">
      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-2xl w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white active:scale-95 transition-transform"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Smartphone className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-xl font-black font-mono text-amber-400 tracking-wider">
              NATIVE ANDROID PROJECT EXPORT
            </h2>
            <p className="text-xs text-white/70">
              KENECITY: LAST STAND — Full Standalone Android Studio & Gradle Package
            </p>
          </div>
        </div>

        {/* Verification Summary */}
        <div className="bg-black/50 border border-white/10 rounded-2xl p-4 text-xs leading-relaxed text-white/80 space-y-3 mb-5">
          <p>
            This export produces a <strong>complete, self-contained native Android project</strong>. The actual 3D game engine, shaders, audio synthesizer, and assets are bundled locally into <code className="text-amber-300 bg-black/60 px-1 py-0.5 rounded">app/src/main/assets/</code> for offline execution.
          </p>

          <div className="grid grid-cols-2 gap-2 font-mono text-[11px] text-amber-300">
            <div>• Package: com.kenecity.laststand</div>
            <div>• Orientation: Landscape Fullscreen</div>
            <div>• Min SDK: 24 (Android 7.0+)</div>
            <div>• Target SDK: 34 (Android 14+)</div>
          </div>
        </div>

        {/* Verified Files Included in the ZIP */}
        <div className="mb-5 space-y-2">
          <div className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>Verified Files Packaged Inside The Downloaded ZIP:</span>
          </div>

          <div className="bg-slate-950 rounded-xl p-3 border border-white/10 text-[11px] font-mono text-white/70 space-y-1.5 max-h-36 overflow-y-auto">
            <div className="text-emerald-400 font-bold">✓ app/src/main/assets/index.html (Offline game entry point)</div>
            <div className="text-emerald-400 font-bold">✓ app/src/main/assets/assets/*.js (3D WebGL engine & game logic)</div>
            <div className="text-emerald-400 font-bold">✓ app/src/main/assets/assets/*.css (Tactical HUD & styling)</div>
            <div className="text-cyan-300">✓ app/src/main/AndroidManifest.xml (Landscape, Fullscreen, Permissions)</div>
            <div className="text-cyan-300">✓ app/src/main/java/com/kenecity/laststand/MainActivity.java</div>
            <div className="text-cyan-300">✓ app/src/main/res/drawable/ic_launcher_*.xml (Launcher icons)</div>
            <div className="text-cyan-300">✓ app/src/main/res/values/*.xml (strings, colors, styles)</div>
            <div className="text-amber-300">✓ app/build.gradle (Android Gradle Plugin, SDK 34, NDK filters)</div>
            <div className="text-amber-300">✓ build.gradle & settings.gradle</div>
            <div className="text-amber-300">✓ gradlew & gradlew.bat (Gradle wrapper scripts)</div>
            <div className="text-amber-300">✓ gradle/wrapper/gradle-wrapper.properties</div>
            <div className="text-white/60">✓ game-source/ (Full raw TypeScript source code)</div>
            <div className="text-white/60">✓ README.md (Step-by-step compilation manual)</div>
          </div>
        </div>

        {/* Terminal Build Command */}
        <div className="space-y-3 mb-6">
          <div className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span>How To Produce The Installable APK:</span>
          </div>

          <div className="bg-slate-950 rounded-xl p-3 border border-white/10 text-xs font-mono space-y-2">
            <div className="flex items-center justify-between text-white/60">
              <span>Terminal Command (run inside extracted folder):</span>
              <button
                type="button"
                onClick={copyBuildCommand}
                className="flex items-center gap-1 text-[11px] text-emerald-400 hover:text-emerald-300 cursor-pointer"
              >
                {copiedCmd ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCmd ? 'Copied' : 'Copy Command'}</span>
              </button>
            </div>
            <code className="text-emerald-400 block bg-black/60 p-2 rounded-lg font-bold">
              ./gradlew assembleDebug
            </code>
            <p className="text-[11px] text-white/50">
              Output APK path: <span className="text-amber-300">app/build/outputs/apk/debug/app-debug.apk</span>
            </p>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex flex-col gap-3">
          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={isDownloading}
            className="w-full py-3.5 px-6 rounded-2xl bg-linear-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-mono font-black text-sm shadow-xl flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer"
          >
            {isDownloading ? (
              <span>PACKAGING ANDROID PROJECT WITH ASSETS...</span>
            ) : (
              <>
                <FolderArchive className="w-5 h-5" />
                <span>DOWNLOAD COMPLETE ANDROID PROJECT (.ZIP)</span>
              </>
            )}
          </button>

          {downloadSuccess && (
            <div className="flex items-center justify-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 p-2.5 rounded-xl">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>Project ZIP exported with all game assets included in app/src/main/assets!</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
