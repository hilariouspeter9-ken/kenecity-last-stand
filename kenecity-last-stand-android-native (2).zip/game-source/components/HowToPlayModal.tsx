/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Smartphone, Keyboard, Shield, Target, Crosshair, Flame, Bomb } from 'lucide-react';
import { soundManager } from '../audio/SoundManager';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 font-sans">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-xl w-full p-6 text-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={() => {
            soundManager.playButtonClick();
            onClose();
          }}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white active:scale-95 transition-transform"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-black font-mono text-amber-400 tracking-wider mb-2">
          COMBAT TACTICS & FIELD MANUAL
        </h2>
        <p className="text-xs text-white/60 mb-5">OPERATIONAL GUIDE FOR KENECITY SPECIAL OPERATIVES</p>

        {/* Section 1: Mobile Touchscreen Controls */}
        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-300">
            <Smartphone className="w-4 h-4" />
            <span>ANDROID LANDSCAPE TOUCHSCREEN CONTROLS:</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div className="bg-black/40 border border-white/5 rounded-xl p-2.5">
              <span className="font-bold text-emerald-400 block mb-0.5">Left Thumb Joystick:</span>
              <span className="text-white/70 text-[11px]">Drag thumb to move & strafe in 360 degrees.</span>
            </div>

            <div className="bg-black/40 border border-white/5 rounded-xl p-2.5">
              <span className="font-bold text-cyan-400 block mb-0.5">Right Touch Area:</span>
              <span className="text-white/70 text-[11px]">Swipe anywhere on right half to look & aim smoothly.</span>
            </div>

            <div className="bg-black/40 border border-white/5 rounded-xl p-2.5">
              <span className="font-bold text-red-400 block mb-0.5">Fire & Aim (ADS):</span>
              <span className="text-white/70 text-[11px]">Tap or hold big red button to shoot; tap AIM to zoom over shoulder.</span>
            </div>

            <div className="bg-black/40 border border-white/5 rounded-xl p-2.5">
              <span className="font-bold text-amber-400 block mb-0.5">Tactical Actions:</span>
              <span className="text-white/70 text-[11px]">Crouch (reduces spread), Sprint (high speed), Swap Gun, Throw Grenade.</span>
            </div>
          </div>
        </div>

        {/* Section 2: Desktop / PC Controls */}
        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-cyan-300">
            <Keyboard className="w-4 h-4" />
            <span>DESKTOP KEYBOARD & MOUSE CONTROLS:</span>
          </div>

          <div className="bg-black/40 border border-white/5 rounded-xl p-3 text-xs font-mono grid grid-cols-2 gap-2 text-white/80">
            <div>• <strong className="text-white">WASD / Arrows:</strong> Walk & Strafe</div>
            <div>• <strong className="text-white">Mouse:</strong> Look & Aim (Right click to ADS)</div>
            <div>• <strong className="text-white">Left Click:</strong> Fire Weapon</div>
            <div>• <strong className="text-white">Spacebar:</strong> Jump</div>
            <div>• <strong className="text-white">C:</strong> Toggle Crouch</div>
            <div>• <strong className="text-white">Shift:</strong> Hold to Sprint</div>
            <div>• <strong className="text-white">R:</strong> Reload Magazine</div>
            <div>• <strong className="text-white">Q / E:</strong> Switch Weapon</div>
            <div>• <strong className="text-white">G:</strong> Throw Frag Grenade</div>
            <div>• <strong className="text-white">P:</strong> Pause Combat</div>
          </div>
        </div>

        {/* Section 3: Tactical Tips */}
        <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-2xl p-4 text-xs space-y-1.5 text-emerald-200">
          <span className="font-mono font-bold block text-emerald-400">COMMANDER ADVICE:</span>
          <p>• Shoot red explosive barrels to wipe out hostile squads or vehicle barricades in one blast!</p>
          <p>• Aim for headshots for 2.2x critical multiplier damage.</p>
          <p>• Crouch behind sandbag barriers to reduce weapon spread and take cover from incoming sniper rounds.</p>
          <p>• Pick up supply crates dropped by fallen enemies to replenish armor and reserve ammunition.</p>
        </div>

        <div className="mt-6 pt-4 border-t border-white/10 flex justify-end">
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onClose();
            }}
            className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-mono font-bold text-xs shadow-lg active:scale-95 transition-all"
          >
            DISMISS FIELD MANUAL
          </button>
        </div>
      </div>
    </div>
  );
};
