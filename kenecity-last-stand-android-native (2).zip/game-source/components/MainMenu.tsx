/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { UserProgression } from '../types/game';
import {
  Play,
  Crosshair,
  Shield,
  Smartphone,
  Settings,
  HelpCircle,
  Award,
  Star,
  Download,
} from 'lucide-react';
import { soundManager } from '../audio/SoundManager';

interface MainMenuProps {
  progression: UserProgression;
  onStartCampaign: () => void;
  onOpenArmory: () => void;
  onOpenSettings: () => void;
  onOpenAndroidExport: () => void;
  onOpenHowToPlay: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  progression,
  onStartCampaign,
  onOpenArmory,
  onOpenSettings,
  onOpenAndroidExport,
  onOpenHowToPlay,
}) => {
  const totalStars = Object.values(progression.missionStars).reduce((a, b) => a + b, 0);

  return (
    <div className="absolute inset-0 bg-slate-950 text-white flex flex-col justify-between p-6 z-30 overflow-y-auto font-sans select-none">
      {/* Background Military Gradient & Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black pointer-events-none opacity-90" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f293715_1px,transparent_1px),linear-gradient(to_bottom,#1f293715_1px,transparent_1px)] bg-[size:4rem_4rem] pointer-events-none" />

      {/* TOP BAR: Player Rank & Operative Badges */}
      <div className="relative z-10 flex items-center justify-between max-w-5xl mx-auto w-full border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-mono text-emerald-400 font-bold uppercase">
              OPERATIVE PROFILE
            </div>
            <div className="text-sm font-black text-white font-mono flex items-center gap-2">
              <span>{progression.rankTitle}</span>
              <span className="text-white/40">|</span>
              <span className="text-amber-400 text-xs">{progression.xp} XP</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 flex items-center gap-1.5 text-amber-400">
            <Star className="w-4 h-4 fill-amber-400" />
            <span className="font-bold">{totalStars} / 15 STARS</span>
          </div>

          <div className="bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 flex items-center gap-1.5 text-red-400">
            <Crosshair className="w-4 h-4" />
            <span className="font-bold">{progression.totalKills} KILLS</span>
          </div>
        </div>
      </div>

      {/* CENTER: Main Title & Action Buttons */}
      <div className="relative z-10 flex flex-col items-center justify-center my-auto py-8 text-center max-w-3xl mx-auto w-full">
        {/* Title Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/40 text-[11px] font-mono text-red-300 font-bold tracking-widest uppercase mb-4 shadow-lg">
          <Crosshair className="w-3.5 h-3.5 text-red-400 animate-spin" />
          <span>STANDALONE 3D MILITARY SHOOTER</span>
        </div>

        {/* Main Title */}
        <h1 className="text-4xl sm:text-6xl font-black tracking-widest text-transparent bg-clip-text bg-linear-to-b from-white via-slate-200 to-slate-400 font-mono mb-2 drop-shadow-md">
          KENECITY
        </h1>
        <h2 className="text-xl sm:text-2xl font-black tracking-[0.35em] text-amber-400 font-mono mb-8 drop-shadow-[0_0_12px_rgba(245,158,11,0.4)]">
          LAST STAND
        </h2>

        {/* Menu Buttons Grid */}
        <div className="flex flex-col sm:flex-row flex-wrap items-center justify-center gap-3 w-full max-w-md">
          {/* PLAY CAMPAIGN (Main CTA) */}
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onStartCampaign();
            }}
            className="w-full py-4 px-6 rounded-2xl bg-linear-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-mono font-black text-sm shadow-[0_0_25px_rgba(245,158,11,0.4)] flex items-center justify-center gap-2.5 active:scale-95 transition-all cursor-pointer"
          >
            <Play className="w-5 h-5 fill-black" />
            <span>PLAY CAMPAIGN</span>
          </button>

          {/* WEAPONS ARMORY */}
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenArmory();
            }}
            className="flex-1 min-w-[140px] py-3 px-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-white font-mono font-bold text-xs border border-white/10 flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md cursor-pointer"
          >
            <Crosshair className="w-4 h-4 text-emerald-400" />
            <span>ARMORY</span>
          </button>

          {/* ANDROID PROJECT / APK EXPORT */}
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenAndroidExport();
            }}
            className="flex-1 min-w-[140px] py-3 px-4 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 font-mono font-bold text-xs border border-emerald-500/40 flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>ANDROID APK</span>
          </button>

          {/* SETTINGS */}
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenSettings();
            }}
            className="flex-1 min-w-[140px] py-3 px-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-white font-mono font-bold text-xs border border-white/10 flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md cursor-pointer"
          >
            <Settings className="w-4 h-4 text-amber-400" />
            <span>SETTINGS</span>
          </button>

          {/* HOW TO PLAY */}
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenHowToPlay();
            }}
            className="flex-1 min-w-[140px] py-3 px-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-white font-mono font-bold text-xs border border-white/10 flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-cyan-400" />
            <span>HOW TO PLAY</span>
          </button>
        </div>
      </div>

      {/* FOOTER: Technical Spec & Platform Capability */}
      <div className="relative z-10 max-w-5xl mx-auto w-full pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-[11px] text-white/50 font-mono gap-2">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span>SAMSUNG & ANDROID SMARTPHONE READY • 3D ENGINE • 60 FPS</span>
        </div>
        <div>
          <span>OFFLINE SINGLE PLAYER CAMPAIGN • PERSISTENT SAVE</span>
        </div>
      </div>
    </div>
  );
};
