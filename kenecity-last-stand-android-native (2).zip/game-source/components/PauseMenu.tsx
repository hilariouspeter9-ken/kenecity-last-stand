/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, RotateCcw, Settings, Home } from 'lucide-react';
import { soundManager } from '../audio/SoundManager';

interface PauseMenuProps {
  onResume: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
  onExitToMainMenu: () => void;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({
  onResume,
  onRestart,
  onOpenSettings,
  onExitToMainMenu,
}) => {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-40 font-sans">
      <div className="bg-slate-900 border border-white/20 rounded-3xl max-w-sm w-full p-6 text-white shadow-2xl flex flex-col items-center">
        <h2 className="text-xl font-black font-mono text-amber-400 tracking-widest mb-1">
          COMBAT PAUSED
        </h2>
        <p className="text-xs text-white/60 mb-6">KENECITY: LAST STAND</p>

        <div className="w-full flex flex-col gap-3">
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onResume();
            }}
            className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-mono font-black text-xs shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Play className="w-4 h-4 fill-black" />
            <span>RESUME MISSION</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onRestart();
            }}
            className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-mono font-bold text-xs border border-white/10 flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>RESTART MISSION</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenSettings();
            }}
            className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-mono font-bold text-xs border border-white/10 flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Settings className="w-4 h-4" />
            <span>SYSTEM SETTINGS</span>
          </button>

          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onExitToMainMenu();
            }}
            className="w-full py-3 rounded-xl bg-red-950/60 hover:bg-red-900/80 text-red-300 font-mono font-bold text-xs border border-red-500/30 flex items-center justify-center gap-2 active:scale-95 transition-all mt-2"
          >
            <Home className="w-4 h-4" />
            <span>ABANDON TO MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
