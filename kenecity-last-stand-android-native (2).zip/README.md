# KENECITY: LAST STAND — COMPLETE NATIVE ANDROID GAME PROJECT

Application Name: KENECITY: LAST STAND
Package: com.kenecity.laststand
Target Architecture: Android 7.0+ (SDK 24 to SDK 34)
Display: Landscape Fullscreen Immersive

---

## 1. PROJECT VERIFICATION
All required game assets, engines, 3D procedural modules, and graphics have been compiled directly into:
`app/src/main/assets/`
- `index.html`: Offline game entry point (relative local paths)
- `assets/*.js`: Complete Three.js 3D engine, enemy AI, weapons, 5 campaign missions, audio synthesizer
- `assets/*.css`: Complete HUD styles and responsive touch controls

## 2. HOW TO BUILD THE STANDALONE APK:

### METHOD 1: Android Studio (Recommended GUI)
1. Launch Android Studio.
2. Select **Open** and choose this extracted project folder (`kenecity-last-stand-android-native`).
3. Allow Gradle sync to finish.
4. Go to top menu: **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
5. In bottom right notification, click **locate** to get:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Install `app-debug.apk` on your Samsung smartphone via USB, adb (`adb install app-debug.apk`), or Google Drive!

### METHOD 2: Command Line (Linux / macOS / Windows WSL / Termux)
```bash
chmod +x gradlew
./gradlew assembleDebug
```
The generated APK will be immediately ready at:
`app/build/outputs/apk/debug/app-debug.apk`

No website redirection, no PWABuilder, no online dependence. Tap the icon in your Android app drawer to play immediately!